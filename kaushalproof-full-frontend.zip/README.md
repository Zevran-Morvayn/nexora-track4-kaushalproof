# KaushalProof – frontend

Frontend for a platform connecting skilled workers, employers and assessors. Three roles only (no admin). It runs on **sample data** with **mock login**; there is no backend yet.

Built with React 19, Vite, Tailwind CSS 4, React Router, lucide-react icons and react-qr-code.

## Run it

You need Node.js 20.19+ (or 22).

```bash
npm install
npm run dev
```

Open the link it prints (usually http://localhost:5173).

## Try it

- **Log in:** on the login page, pick Worker, Employer or Assessor under "DEMO: log in as", then press Log in. Any email/password works.
- **Register:** choose a role → Continue → enter any 6 digits on the OTP screen.
- **Dark mode:** moon icon in the header. **Language:** English / हिन्दी / ಕನ್ನಡ selector (main navigation labels).
- To change the app name, edit `APP_NAME` in `src/context/AppContext.jsx`.

## What's included

**Public:** home, browse workers (filters, sort by nearest), worker profile with QR, browse jobs, browse assessments, certificate verify page (`/verify/KP-7F3K9Q`), about, services and plans, help center and FAQ, contact, success stories and reviews, blog, careers, privacy, terms, app download section.

**Auth:** login, register with role selection, Google / Apple buttons, OTP verification, forgot and reset password.

**Worker:** dashboard (offers accept/decline, AI skill-gap analysis, AI-matched jobs), profile (photo, skills, experience, location, availability, preferences, documents, portfolio, emergency contact), jobs and applications, work history, skill verification (video upload, certificates with QR), earnings and attendance, digital ID card.

**Employer:** dashboard analytics and AI recommendations, company profile, job listings (edit/close), post a job, find workers, candidates pipeline (shortlist → interview → hire), workforce attendance, saved workers.

**Assessor:** dashboard analytics, assessment programs (create), evaluate workers (video, checklist, AI pre-check, score, report, approve/reject), certificates with QR, worker rankings, assessment history.

**All roles:** messages (chat, voice/video call buttons, group rooms, announcements), notifications, calendar, activity log, plans and billing (transactions, invoices, refunds), support tickets and FAQ, settings (account, security, notifications, language, dark mode).

## Connecting a backend later

- Sample data lives in `src/data/mock.js`. Replace imports from it with API calls.
- Mock login is in `src/context/AppContext.jsx` (`login`, `logout`).
- Payments, calls, SMS/email and AI features are UI only; buttons show a "demo" message.

## Structure

```
src/
  App.jsx               routes
  context/AppContext.jsx  theme, language, mock auth, saved items
  data/mock.js          sample data
  components/           layouts, cards, UI kit
  pages/public/         public pages
  pages/auth/           login, register, OTP, password reset
  pages/worker/         worker module
  pages/employer/       employer module
  pages/assessor/       assessor module
  pages/app/            shared dashboard pages
```
