import { useEffect } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import PublicLayout from "./components/PublicLayout";
import DashboardLayout from "./components/DashboardLayout";
import { useApp } from "./context/AppContext";

import Home from "./pages/public/Home";
import { BrowseWorkers, WorkerPublicProfile, BrowseJobs, BrowseAssessments, VerifyCertificate } from "./pages/public/Browse";
import { About, Services, Help, Contact, Stories, Blog, Careers, Legal, NotFound } from "./pages/public/Info";
import { Login, Register, VerifyOtp, ForgotPassword, ResetPassword } from "./pages/auth/Auth";

import { Dashboard, Messages, Notifications, CalendarPage, ActivityLog, Billing, Support, Settings } from "./pages/app/Common";
import { WorkerProfile, WorkerJobs, WorkerVerification, WorkerEarnings, WorkerIdCard } from "./pages/worker/Worker";
import { CompanyProfile, EmployerJobs, PostJob, FindWorkers, Candidates, Workforce, SavedWorkers } from "./pages/employer/Employer";
import { Programs, Evaluate, Certificates, Rankings, AssessmentHistory } from "./pages/assessor/Assessor";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

// Only lets the signed-in role see its own module.
function Only({ role, children }) {
  const { user } = useApp();
  return user?.role === role ? children : <Navigate to="/app" replace />;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/workers" element={<BrowseWorkers />} />
          <Route path="/workers/:id" element={<WorkerPublicProfile />} />
          <Route path="/jobs" element={<BrowseJobs />} />
          <Route path="/assessments" element={<BrowseAssessments />} />
          <Route path="/verify/:id" element={<VerifyCertificate />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/help" element={<Help />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/stories" element={<Stories />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/legal/:page" element={<Legal />} />
          <Route path="*" element={<NotFound />} />
        </Route>

        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/verify-otp" element={<VerifyOtp />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        <Route path="/app" element={<DashboardLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="messages" element={<Messages />} />
          <Route path="notifications" element={<Notifications />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="activity" element={<ActivityLog />} />
          <Route path="billing" element={<Billing />} />
          <Route path="support" element={<Support />} />
          <Route path="settings" element={<Settings />} />

          <Route path="worker/profile" element={<Only role="worker"><WorkerProfile /></Only>} />
          <Route path="worker/jobs" element={<Only role="worker"><WorkerJobs /></Only>} />
          <Route path="worker/verification" element={<Only role="worker"><WorkerVerification /></Only>} />
          <Route path="worker/earnings" element={<Only role="worker"><WorkerEarnings /></Only>} />
          <Route path="worker/id-card" element={<Only role="worker"><WorkerIdCard /></Only>} />

          <Route path="employer/company" element={<Only role="employer"><CompanyProfile /></Only>} />
          <Route path="employer/jobs" element={<Only role="employer"><EmployerJobs /></Only>} />
          <Route path="employer/post-job" element={<Only role="employer"><PostJob /></Only>} />
          <Route path="employer/search" element={<Only role="employer"><FindWorkers /></Only>} />
          <Route path="employer/candidates" element={<Only role="employer"><Candidates /></Only>} />
          <Route path="employer/workforce" element={<Only role="employer"><Workforce /></Only>} />
          <Route path="employer/saved" element={<Only role="employer"><SavedWorkers /></Only>} />

          <Route path="assessor/programs" element={<Only role="assessor"><Programs /></Only>} />
          <Route path="assessor/evaluate" element={<Only role="assessor"><Evaluate /></Only>} />
          <Route path="assessor/certificates" element={<Only role="assessor"><Certificates /></Only>} />
          <Route path="assessor/rankings" element={<Only role="assessor"><Rankings /></Only>} />
          <Route path="assessor/history" element={<Only role="assessor"><AssessmentHistory /></Only>} />
        </Route>
      </Routes>
    </>
  );
}
