import { useState } from "react";
import { NavLink, Outlet, Navigate, useNavigate, Link } from "react-router-dom";
import {
  LayoutDashboard, User, Briefcase, Wallet, IdCard, ShieldCheck, MessageSquare, Bell, CalendarDays, Settings, CreditCard,
  LifeBuoy, Search, Users, Bookmark, ClipboardList, Award, Trophy, History, PlusCircle, Building2, Activity, Menu, LogOut, X,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import { Logo, ThemeToggle, LangSelect, Toast } from "./PublicLayout";
import { Avatar } from "./ui";
import { notifications } from "../data/mock";

const menus = {
  worker: [
    ["/app", "Dashboard", LayoutDashboard],
    ["/app/worker/profile", "My profile", User],
    ["/app/worker/jobs", "Jobs & applications", Briefcase],
    ["/app/worker/verification", "Skill verification", ShieldCheck],
    ["/app/worker/earnings", "Earnings & attendance", Wallet],
    ["/app/worker/id-card", "Digital ID card", IdCard],
  ],
  employer: [
    ["/app", "Dashboard", LayoutDashboard],
    ["/app/employer/company", "Company profile", Building2],
    ["/app/employer/jobs", "Job listings", Briefcase],
    ["/app/employer/post-job", "Post a job", PlusCircle],
    ["/app/employer/search", "Find workers", Search],
    ["/app/employer/candidates", "Candidates", Users],
    ["/app/employer/workforce", "Workforce", ClipboardList],
    ["/app/employer/saved", "Saved workers", Bookmark],
  ],
  assessor: [
    ["/app", "Dashboard", LayoutDashboard],
    ["/app/assessor/programs", "Programs", ClipboardList],
    ["/app/assessor/evaluate", "Evaluate workers", ShieldCheck],
    ["/app/assessor/certificates", "Certificates", Award],
    ["/app/assessor/rankings", "Worker rankings", Trophy],
    ["/app/assessor/history", "Assessment history", History],
  ],
};

const common = [
  ["/app/messages", "Messages", MessageSquare],
  ["/app/notifications", "Notifications", Bell],
  ["/app/calendar", "Calendar", CalendarDays],
  ["/app/activity", "Activity log", Activity],
  ["/app/billing", "Plans & billing", CreditCard],
  ["/app/support", "Support", LifeBuoy],
  ["/app/settings", "Settings", Settings],
];

export default function DashboardLayout() {
  const { user, logout } = useApp();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  if (!user) return <Navigate to="/login" replace />;

  const unread = notifications.filter((n) => !n.read).length;
  const item = ({ isActive }) =>
    `flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition ${
      isActive ? "bg-brand-600 text-white" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
    }`;

  const Sidebar = (
    <aside className="w-64 shrink-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 h-full overflow-y-auto p-4 flex flex-col">
      <Logo />
      <p className="mt-6 mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">{user.role}</p>
      <nav className="space-y-1">
        {menus[user.role].map(([to, label, Icon]) => (
          <NavLink key={to} to={to} end={to === "/app"} className={item} onClick={() => setOpen(false)}>
            <Icon size={18} /> {label}
          </NavLink>
        ))}
      </nav>
      <p className="mt-6 mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">General</p>
      <nav className="space-y-1">
        {common.map(([to, label, Icon]) => (
          <NavLink key={to} to={to} className={item} onClick={() => setOpen(false)}>
            <Icon size={18} /> {label}
          </NavLink>
        ))}
      </nav>
      <button
        onClick={() => { logout(); navigate("/"); }}
        className="mt-auto flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
      >
        <LogOut size={18} /> Log out
      </button>
    </aside>
  );

  return (
    <div className="h-screen flex overflow-hidden">
      <div className="hidden lg:block">{Sidebar}</div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {Sidebar}
          <button className="flex-1 bg-black/40" onClick={() => setOpen(false)} aria-label="Close menu"><X className="ml-auto m-4 text-white" /></button>
        </div>
      )}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 shrink-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 px-4">
          <button className="lg:hidden p-2" onClick={() => setOpen(true)} aria-label="Open menu"><Menu /></button>
          <div className="hidden sm:flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 w-full max-w-sm">
            <Search size={16} className="text-slate-400" />
            <input placeholder="Search workers, jobs, assessments…" className="bg-transparent outline-none text-sm w-full" />
          </div>
          <div className="ml-auto flex items-center gap-2">
            <LangSelect />
            <ThemeToggle />
            <Link to="/app/notifications" className="relative p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Notifications">
              <Bell size={18} />
              {unread > 0 && <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">{unread}</span>}
            </Link>
            <Link to="/app/settings" className="flex items-center gap-2">
              <Avatar initials={user.initials} size="sm" />
              <span className="hidden md:block text-sm font-semibold">{user.name}</span>
            </Link>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50 dark:bg-slate-950">
          <Outlet />
        </main>
      </div>
      <Toast />
    </div>
  );
}
