import { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { Moon, Sun, Menu, X, Hammer, Globe } from "lucide-react";
import { useApp, APP_NAME } from "../context/AppContext";
import { Button } from "./ui";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-extrabold text-lg text-slate-900 dark:text-white">
      <span className="w-8 h-8 rounded-lg bg-brand-600 text-white flex items-center justify-center">
        <Hammer size={18} />
      </span>
      {APP_NAME}
    </Link>
  );
}

export function ThemeToggle() {
  const { theme, toggleTheme } = useApp();
  return (
    <button onClick={toggleTheme} aria-label="Toggle dark mode" className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

export function LangSelect() {
  const { lang, setLang } = useApp();
  return (
    <label className="flex items-center gap-1 text-sm">
      <Globe size={16} />
      <select value={lang} onChange={(e) => setLang(e.target.value)} className="bg-transparent outline-none" aria-label="Language">
        <option value="en">English</option>
        <option value="hi">हिन्दी</option>
        <option value="kn">ಕನ್ನಡ</option>
      </select>
    </label>
  );
}

export function Toast() {
  const { toast } = useApp();
  if (!toast) return null;
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white dark:bg-white dark:text-slate-900 px-4 py-2 rounded-xl shadow-lg text-sm fade-up">
      {toast}
    </div>
  );
}

export default function PublicLayout() {
  const { t, user } = useApp();
  const [open, setOpen] = useState(false);
  const links = [
    { to: "/workers", label: t("findWorkers") },
    { to: "/jobs", label: t("jobs") },
    { to: "/assessments", label: t("assessments") },
    { to: "/services", label: "Services" },
    { to: "/about", label: "About" },
    { to: "/help", label: "Help" },
  ];
  const navCls = ({ isActive }) => `text-sm font-medium ${isActive ? "text-brand-600 dark:text-brand-100" : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`;

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-6">
          <Logo />
          <nav className="hidden lg:flex gap-6">
            {links.map((l) => <NavLink key={l.to} to={l.to} className={navCls}>{l.label}</NavLink>)}
          </nav>
          <div className="ml-auto hidden md:flex items-center gap-3">
            <LangSelect />
            <ThemeToggle />
            {user ? (
              <Button to="/app">{t("dashboard")}</Button>
            ) : (
              <>
                <Button variant="ghost" to="/login">{t("login")}</Button>
                <Button to="/register">{t("register")}</Button>
              </>
            )}
          </div>
          <button className="ml-auto md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X /> : <Menu />}
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t border-slate-200 dark:border-slate-800 px-4 py-4 space-y-3 bg-white dark:bg-slate-950">
            {links.map((l) => <NavLink key={l.to} to={l.to} className={navCls} onClick={() => setOpen(false)} style={{ display: "block" }}>{l.label}</NavLink>)}
            <div className="flex items-center gap-3 pt-2"><LangSelect /><ThemeToggle /></div>
            <div className="flex gap-2">
              <Button variant="outline" to="/login" className="flex-1">{t("login")}</Button>
              <Button to="/register" className="flex-1">{t("register")}</Button>
            </div>
          </div>
        )}
      </header>
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <Toast />
    </div>
  );
}

function Footer() {
  const cols = [
    { title: "Platform", links: [["/workers", "Browse workers"], ["/jobs", "Browse jobs"], ["/assessments", "Assessments"], ["/services", "Services"]] },
    { title: "Company", links: [["/about", "About us"], ["/careers", "Careers"], ["/blog", "Blog & news"], ["/stories", "Success stories"]] },
    { title: "Support", links: [["/help", "Help center"], ["/contact", "Contact us"], ["/legal/privacy", "Privacy policy"], ["/legal/terms", "Terms & conditions"]] },
  ];
  return (
    <footer className="bg-slate-900 text-slate-300 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12 grid md:grid-cols-4 gap-8">
        <div>
          <p className="font-extrabold text-white text-lg">{APP_NAME}</p>
          <p className="text-sm mt-2 text-slate-400">Verified skills. Trusted hiring. Built for India’s skilled workforce.</p>
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <p className="font-semibold text-white mb-3">{c.title}</p>
            <ul className="space-y-2 text-sm">
              {c.links.map(([to, label]) => <li key={to}><Link to={to} className="hover:text-white">{label}</Link></li>)}
            </ul>
          </div>
        ))}
      </div>
      <p className="text-center text-xs text-slate-500 pb-6">© 2026 {APP_NAME}. Sample data for demonstration.</p>
    </footer>
  );
}
