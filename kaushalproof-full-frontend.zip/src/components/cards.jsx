import { Link } from "react-router-dom";
import { MapPin, Bookmark, BookmarkCheck, Clock, Users } from "lucide-react";
import { Card, Avatar, Rating, VerifiedBadge, Badge, Button, statusColor } from "./ui";
import { useApp } from "../context/AppContext";
import { employerById } from "../data/mock";

export function WorkerCard({ w, actions }) {
  const { saved, toggleSaved, notify } = useApp();
  const isSaved = saved.includes(w.id);
  return (
    <Card className="p-5 flex flex-col gap-3 hover:shadow-md transition fade-up">
      <div className="flex items-start gap-3">
        <Avatar initials={w.photo} />
        <div className="flex-1 min-w-0">
          <Link to={`/workers/${w.id}`} className="font-semibold hover:text-brand-600 dark:hover:text-brand-100">{w.name}</Link>
          <p className="text-sm text-slate-500 dark:text-slate-400">{w.trade} · {w.years} yrs</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5"><MapPin size={12} />{w.area}, {w.city}</p>
        </div>
        <button
          onClick={() => { toggleSaved(w.id); notify(isSaved ? "Removed from saved" : "Saved worker"); }}
          aria-label="Save worker"
          className="text-slate-400 hover:text-brand-600"
        >
          {isSaved ? <BookmarkCheck className="text-brand-600" size={20} /> : <Bookmark size={20} />}
        </button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {w.verified.map((s) => <VerifiedBadge key={s}>{s}</VerifiedBadge>)}
        {w.verified.length === 0 && <Badge>Not yet verified</Badge>}
      </div>
      <div className="flex items-center justify-between text-sm mt-auto pt-2">
        <Rating value={w.rating} count={w.reviews} />
        <span className="font-semibold">₹{w.rate}/day</span>
      </div>
      <div className="flex items-center justify-between">
        <Badge color={w.available ? "green" : "gray"}>{w.available ? "Available" : "Busy"}</Badge>
        {actions || <Button variant="outline" to={`/workers/${w.id}`} className="!py-1.5">View profile</Button>}
      </div>
    </Card>
  );
}

export function JobCard({ j, action }) {
  const e = employerById(j.employerId);
  return (
    <Card className="p-5 flex flex-col gap-3 hover:shadow-md transition fade-up">
      <div className="flex justify-between gap-3">
        <div>
          <p className="font-semibold">{j.title}</p>
          <p className="text-sm text-slate-500 dark:text-slate-400">{e?.name}</p>
        </div>
        <Badge color={statusColor(j.status)}>{j.status}</Badge>
      </div>
      <p className="text-sm text-slate-600 dark:text-slate-300">{j.description}</p>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1"><MapPin size={12} />{j.area}, {j.city}</span>
        <span className="flex items-center gap-1"><Clock size={12} />{j.posted}</span>
        <span className="flex items-center gap-1"><Users size={12} />{j.applicants} applicants</span>
      </div>
      <div className="flex items-center justify-between mt-auto pt-1">
        <div>
          <p className="font-semibold">{j.pay}</p>
          <p className="text-xs text-slate-500">{j.type}</p>
        </div>
        {action}
      </div>
    </Card>
  );
}
