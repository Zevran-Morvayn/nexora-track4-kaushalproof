import { Star, BadgeCheck, Inbox } from "lucide-react";
import { Link } from "react-router-dom";

export function Card({ className = "", children, ...rest }) {
  return (
    <div className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm ${className}`} {...rest}>
      {children}
    </div>
  );
}

export function CardHeader({ title, action, subtitle }) {
  return (
    <div className="flex items-start justify-between gap-3 px-5 pt-5 pb-3">
      <div>
        <h3 className="font-semibold text-slate-900 dark:text-white">{title}</h3>
        {subtitle && <p className="text-sm text-slate-500 dark:text-slate-400">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6 fade-up">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{title}</h1>
        {subtitle && <p className="text-slate-500 dark:text-slate-400 mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

const btn = {
  primary: "bg-brand-600 hover:bg-brand-700 text-white",
  accent: "bg-accent-500 hover:bg-accent-600 text-slate-900",
  outline: "border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800",
  ghost: "hover:bg-slate-100 dark:hover:bg-slate-800",
  danger: "bg-red-600 hover:bg-red-700 text-white",
  success: "bg-emerald-600 hover:bg-emerald-700 text-white",
};

export function Button({ variant = "primary", className = "", to, children, ...rest }) {
  const cls = `inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition disabled:opacity-50 ${btn[variant]} ${className}`;
  if (to) return <Link to={to} className={cls}>{children}</Link>;
  return <button className={cls} {...rest}>{children}</button>;
}

const badge = {
  green: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  amber: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  red: "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
  blue: "bg-brand-100 text-brand-700 dark:bg-brand-700/30 dark:text-brand-100",
  gray: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
};

export function Badge({ color = "gray", children }) {
  return <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${badge[color]}`}>{children}</span>;
}

export function statusColor(s) {
  return (
    {
      Open: "green", Approved: "green", Paid: "green", Hired: "green", Accepted: "green", Resolved: "green", Shortlisted: "blue",
      Pending: "amber", Applied: "amber", Interviewing: "blue", Scheduled: "blue",
      Rejected: "red", Closed: "gray", Refunded: "gray", Declined: "red",
    }[s] || "gray"
  );
}

export function Avatar({ initials, size = "md" }) {
  const s = { sm: "w-8 h-8 text-xs", md: "w-11 h-11 text-sm", lg: "w-20 h-20 text-2xl" }[size];
  return (
    <div className={`${s} rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-white font-bold flex items-center justify-center shrink-0`}>
      {initials}
    </div>
  );
}

export function Rating({ value, count }) {
  return (
    <span className="inline-flex items-center gap-1 text-sm">
      <Star size={14} className="fill-accent-500 text-accent-500" /> {value}
      {count != null && <span className="text-slate-400">({count})</span>}
    </span>
  );
}

export function VerifiedBadge({ children }) {
  return (
    <Badge color="green">
      <BadgeCheck size={12} /> {children}
    </Badge>
  );
}

export function Stat({ icon: Icon, label, value, hint, tone = "brand" }) {
  const tones = {
    brand: "bg-brand-100 text-brand-700 dark:bg-brand-700/30 dark:text-brand-100",
    accent: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    green: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    purple: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300",
  };
  return (
    <Card className="p-5 fade-up">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tones[tone]}`}>
          <Icon size={20} />
        </div>
        <div>
          <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
        </div>
      </div>
      {hint && <p className="text-xs text-slate-500 dark:text-slate-400 mt-3">{hint}</p>}
    </Card>
  );
}

export function BarChart({ data, valueKey, labelKey, format = (v) => v }) {
  const max = Math.max(...data.map((d) => d[valueKey]));
  return (
    <div className="flex items-end gap-3 h-48 px-5 pb-5">
      {data.map((d) => (
        <div key={d[labelKey]} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
          <span className="text-xs text-slate-500 dark:text-slate-400">{format(d[valueKey])}</span>
          <div className="w-full rounded-t-lg bg-gradient-to-t from-brand-600 to-brand-500" style={{ height: `${(d[valueKey] / max) * 75}%` }} />
          <span className="text-xs font-medium">{d[labelKey]}</span>
        </div>
      ))}
    </div>
  );
}

export function Input({ label, className = "", ...rest }) {
  return (
    <label className={`block text-sm font-medium ${className}`}>
      {label}
      <input className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500" {...rest} />
    </label>
  );
}

export function Select({ label, options, className = "", ...rest }) {
  return (
    <label className={`block text-sm font-medium ${className}`}>
      {label}
      <select className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2" {...rest}>
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </label>
  );
}

export function Textarea({ label, ...rest }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <textarea className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2" rows={4} {...rest} />
    </label>
  );
}

export function Empty({ text }) {
  return (
    <div className="flex flex-col items-center py-10 text-slate-400">
      <Inbox size={32} />
      <p className="mt-2 text-sm">{text}</p>
    </div>
  );
}

export function Tabs({ tabs, active, onChange }) {
  return (
    <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit mb-4 overflow-x-auto">
      {tabs.map((t) => (
        <button
          key={t}
          onClick={() => onChange(t)}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap ${active === t ? "bg-white dark:bg-slate-900 shadow-sm" : "text-slate-500"}`}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

export function Table({ columns, rows }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
            {columns.map((c) => (
              <th key={c} className="px-5 py-3 font-medium">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-slate-100 dark:border-slate-800 last:border-0">
              {r.map((cell, j) => (
                <td key={j} className="px-5 py-3">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
