import { createContext, useContext, useEffect, useState } from "react";

// App-wide state: theme, language, signed-in user (mock auth), saved items, toasts.
// HACK DAY: replace login/register with real auth (POST /api/auth/*).

export const APP_NAME = "KaushalProof";

const demoUsers = {
  worker: { id: "w1", name: "Ramesh Kumar", role: "worker", email: "ramesh@example.com", initials: "RK" },
  employer: { id: "e1", name: "Priya Nair", role: "employer", company: "BuildRight Constructions", email: "priya@buildright.in", initials: "PN" },
  assessor: { id: "a1", name: "S. Prakash", role: "assessor", org: "Govt ITI, Bengaluru", email: "prakash@iti.gov.in", initials: "SP" },
};

const strings = {
  en: { findWorkers: "Find workers", jobs: "Jobs", assessments: "Assessments", login: "Log in", register: "Get started", dashboard: "Dashboard" },
  hi: { findWorkers: "कारीगर खोजें", jobs: "नौकरियाँ", assessments: "मूल्यांकन", login: "लॉग इन", register: "शुरू करें", dashboard: "डैशबोर्ड" },
  kn: { findWorkers: "ಕೆಲಸಗಾರರನ್ನು ಹುಡುಕಿ", jobs: "ಉದ್ಯೋಗಗಳು", assessments: "ಮೌಲ್ಯಮಾಪನ", login: "ಲಾಗಿನ್", register: "ಪ್ರಾರಂಭಿಸಿ", dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್" },
};

const Ctx = createContext(null);

function load(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
}
function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable */
  }
}

export function AppProvider({ children }) {
  const [theme, setTheme] = useState(() => load("sc-theme", "light"));
  const [lang, setLang] = useState(() => load("sc-lang", "en"));
  const [user, setUser] = useState(() => load("sc-user", null));
  const [saved, setSaved] = useState(() => load("sc-saved", []));
  const [toast, setToast] = useState(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    save("sc-theme", theme);
  }, [theme]);
  useEffect(() => {
    save("sc-lang", lang);
  }, [lang]);
  useEffect(() => {
    save("sc-user", user);
  }, [user]);
  useEffect(() => {
    save("sc-saved", saved);
  }, [saved]);

  function notify(text) {
    setToast(text);
    setTimeout(() => setToast(null), 2500);
  }

  const value = {
    theme,
    toggleTheme: () => setTheme((t) => (t === "dark" ? "light" : "dark")),
    lang,
    setLang,
    t: (k) => strings[lang]?.[k] ?? strings.en[k] ?? k,
    user,
    login: (role) => setUser(demoUsers[role]),
    logout: () => setUser(null),
    saved,
    toggleSaved: (id) => setSaved((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id])),
    notify,
    toast,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  return useContext(Ctx);
}
