// Realistic sample data. Replace with API calls when the backend is ready.

export const categories = ["Electrician", "Plumber", "Carpenter", "Mason", "Welder", "Painter", "Mechanic"];

export const workers = [
  { id: "w1", name: "Ramesh Kumar", trade: "Electrician", city: "Bengaluru", area: "Jayanagar", years: 6, rating: 4.8, reviews: 42, rate: 900, available: true, verified: ["Basic electrical wiring", "Electrical installation"], pending: ["Electrical maintenance"], distanceKm: 2.1, photo: "RK", bio: "Residential and small commercial wiring, switchboards and fault repair." },
  { id: "w2", name: "Anil Shetty", trade: "Electrician", city: "Mysuru", area: "Vijayanagar", years: 9, rating: 4.6, reviews: 31, rate: 1000, available: false, verified: ["Electrical installation", "Electrical safety"], pending: [], distanceKm: 140, photo: "AS", bio: "Industrial panels, three-phase installation, safety audits." },
  { id: "w3", name: "Farida Begum", trade: "Plumber", city: "Bengaluru", area: "Koramangala", years: 4, rating: 4.9, reviews: 18, rate: 800, available: true, verified: ["Pipe fitting"], pending: ["Bathroom installation"], distanceKm: 4.5, photo: "FB", bio: "Leak repair, bathroom fittings, water tank connections." },
  { id: "w4", name: "Suresh Gowda", trade: "Mason", city: "Bengaluru", area: "Yelahanka", years: 12, rating: 4.7, reviews: 56, rate: 950, available: true, verified: ["Brickwork", "Plastering"], pending: [], distanceKm: 11.2, photo: "SG", bio: "Load-bearing brickwork, plastering and tiling for homes." },
  { id: "w5", name: "Joseph D'Souza", trade: "Carpenter", city: "Mangaluru", area: "Kadri", years: 15, rating: 4.9, reviews: 64, rate: 1100, available: true, verified: ["Furniture making", "Door and window fitting"], pending: [], distanceKm: 350, photo: "JD", bio: "Custom furniture, modular kitchens, doors and windows." },
  { id: "w6", name: "Imran Pasha", trade: "Welder", city: "Bengaluru", area: "Peenya", years: 8, rating: 4.5, reviews: 22, rate: 1000, available: false, verified: ["Arc welding"], pending: ["Gas welding"], distanceKm: 9.8, photo: "IP", bio: "Gates, grills, structural steel and fabrication." },
  { id: "w7", name: "Lakshmi Naik", trade: "Painter", city: "Bengaluru", area: "Whitefield", years: 5, rating: 4.7, reviews: 27, rate: 750, available: true, verified: ["Interior painting"], pending: [], distanceKm: 15.4, photo: "LN", bio: "Interior and exterior painting, texture finishes, waterproofing." },
  { id: "w8", name: "Venkatesh Rao", trade: "Mechanic", city: "Hubballi", area: "Vidyanagar", years: 10, rating: 4.6, reviews: 39, rate: 850, available: true, verified: ["Two-wheeler service"], pending: ["Four-wheeler diagnostics"], distanceKm: 410, photo: "VR", bio: "Two-wheeler engine work, servicing and electrical faults." },
];

export const employers = [
  { id: "e1", name: "BuildRight Constructions", city: "Bengaluru", industry: "Residential construction", size: "120 employees", rating: 4.5 },
  { id: "e2", name: "UrbanNest Interiors", city: "Bengaluru", industry: "Interior design", size: "45 employees", rating: 4.7 },
  { id: "e3", name: "Coastal Facility Services", city: "Mangaluru", industry: "Facility management", size: "300 employees", rating: 4.3 },
];

export const jobs = [
  { id: "j1", title: "Electrician for apartment wiring", employerId: "e1", trade: "Electrician", city: "Bengaluru", area: "HSR Layout", pay: "₹900/day", type: "Contract · 3 weeks", posted: "2 days ago", applicants: 14, status: "Open", skills: ["Electrical installation"], description: "Full wiring of a 24-flat apartment block. Verified installation skill preferred." },
  { id: "j2", title: "Plumber for office fit-out", employerId: "e2", trade: "Plumber", city: "Bengaluru", area: "Indiranagar", pay: "₹850/day", type: "Contract · 10 days", posted: "1 day ago", applicants: 6, status: "Open", skills: ["Pipe fitting"], description: "Washroom and pantry plumbing for a 6,000 sq ft office." },
  { id: "j3", title: "Mason for villa project", employerId: "e1", trade: "Mason", city: "Bengaluru", area: "Sarjapur", pay: "₹1,000/day", type: "Contract · 2 months", posted: "5 days ago", applicants: 21, status: "Interviewing", skills: ["Brickwork", "Plastering"], description: "Brickwork and plastering for four villas." },
  { id: "j4", title: "Carpenter for modular kitchens", employerId: "e2", trade: "Carpenter", city: "Bengaluru", area: "Hebbal", pay: "₹1,100/day", type: "Full-time", posted: "Today", applicants: 3, status: "Open", skills: ["Furniture making"], description: "Assemble and install modular kitchens across client sites." },
  { id: "j5", title: "Maintenance electrician", employerId: "e3", trade: "Electrician", city: "Mangaluru", area: "Kankanady", pay: "₹22,000/month", type: "Full-time", posted: "1 week ago", applicants: 32, status: "Open", skills: ["Electrical maintenance"], description: "On-site maintenance for a commercial complex. Shift work." },
  { id: "j6", title: "Welder for gate fabrication", employerId: "e1", trade: "Welder", city: "Bengaluru", area: "Peenya", pay: "₹1,000/day", type: "Contract · 2 weeks", posted: "3 days ago", applicants: 8, status: "Closed", skills: ["Arc welding"], description: "Fabricate and install 12 steel gates." },
];

export const assessmentPrograms = [
  { id: "p1", title: "Electrical Installation – Level 2", trade: "Electrician", mode: "Video + practical", duration: "45 min", fee: "Free (sponsored)", seats: 40, enrolled: 28, next: "2026-12-02", assessor: "S. Prakash" },
  { id: "p2", title: "Plumbing Fundamentals", trade: "Plumber", mode: "Video evidence", duration: "30 min", fee: "₹199", seats: 30, enrolled: 11, next: "2026-12-04", assessor: "R. Menon" },
  { id: "p3", title: "Brickwork & Plastering", trade: "Mason", mode: "On-site practical", duration: "2 hrs", fee: "₹299", seats: 20, enrolled: 20, next: "2026-12-06", assessor: "S. Prakash" },
  { id: "p4", title: "Arc Welding Safety", trade: "Welder", mode: "Video + quiz", duration: "40 min", fee: "₹249", seats: 25, enrolled: 9, next: "2026-12-09", assessor: "K. Hegde" },
];

export const checklists = {
  "Electrical maintenance": ["Fault identified", "Power isolated first", "Faulty part replaced", "Circuit tested"],
  "Bathroom installation": ["Tools shown", "Water supply isolated", "Fittings installed level", "Leak test done"],
  "Gas welding": ["Safety gear worn", "Cylinder checks done", "Clean weld bead", "Area left safe"],
  "Four-wheeler diagnostics": ["Scanner connected", "Fault code read", "Root cause explained", "Test drive done"],
};

export const evaluationQueue = [
  { id: "ev1", workerId: "w1", skill: "Electrical maintenance", submitted: "2026-11-20", status: "Pending" },
  { id: "ev2", workerId: "w3", skill: "Bathroom installation", submitted: "2026-11-21", status: "Pending" },
  { id: "ev3", workerId: "w6", skill: "Gas welding", submitted: "2026-11-22", status: "Pending" },
  { id: "ev4", workerId: "w8", skill: "Four-wheeler diagnostics", submitted: "2026-11-23", status: "Pending" },
];

export const certificates = [
  { id: "KP-7F3K9Q", workerId: "w1", skill: "Basic electrical wiring", issued: "2026-11-03", assessor: "S. Prakash", score: 88 },
  { id: "KP-2M8X4R", workerId: "w1", skill: "Electrical installation", issued: "2026-11-11", assessor: "S. Prakash", score: 91 },
  { id: "KP-9Q4LZT", workerId: "w4", skill: "Brickwork", issued: "2026-10-18", assessor: "S. Prakash", score: 94 },
  { id: "KP-5HX2PA", workerId: "w5", skill: "Furniture making", issued: "2026-09-29", assessor: "K. Hegde", score: 96 },
  { id: "KP-8RT6MB", workerId: "w3", skill: "Pipe fitting", issued: "2026-10-25", assessor: "R. Menon", score: 90 },
];

export const applications = [
  { id: "ap1", jobId: "j1", status: "Shortlisted", applied: "2026-11-21" },
  { id: "ap2", jobId: "j5", status: "Applied", applied: "2026-11-18" },
  { id: "ap3", jobId: "j6", status: "Rejected", applied: "2026-11-10" },
];

export const offers = [
  { id: "of1", employerId: "e2", title: "Switchboard upgrade, 3 shops", pay: "₹4,500 total", date: "2026-11-28", status: "Pending" },
  { id: "of2", employerId: "e1", title: "Emergency fault repair", pay: "₹1,200", date: "2026-11-25", status: "Pending" },
];

export const earnings = [
  { month: "Jun", amount: 18400 }, { month: "Jul", amount: 21200 }, { month: "Aug", amount: 19800 },
  { month: "Sep", amount: 24600 }, { month: "Oct", amount: 26100 }, { month: "Nov", amount: 23900 },
];

export const workHistory = [
  { id: "h1", employer: "BuildRight Constructions", job: "Villa wiring, Sarjapur", from: "2026-10-01", to: "2026-10-24", pay: "₹19,800", rating: 5 },
  { id: "h2", employer: "UrbanNest Interiors", job: "Office lighting, Indiranagar", from: "2026-09-08", to: "2026-09-20", pay: "₹10,800", rating: 4 },
  { id: "h3", employer: "Private client", job: "Home rewiring, Jayanagar", from: "2026-08-12", to: "2026-08-18", pay: "₹6,300", rating: 5 },
];

export const attendance = ["P", "P", "P", "A", "P", "P", "H", "P", "P", "P", "P", "P", "H", "H", "P", "P", "A", "P", "P", "P", "H", "P", "P", "P"];

export const conversations = [
  { id: "c1", with: "BuildRight Constructions", role: "Employer", last: "Can you start Monday at 9?", time: "10:42", unread: 2,
    messages: [
      { from: "them", text: "Hi Ramesh, we saw your verified installation credential.", time: "10:30" },
      { from: "me", text: "Thank you! I'm available from next week.", time: "10:35" },
      { from: "them", text: "Can you start Monday at 9?", time: "10:42" },
    ] },
  { id: "c2", with: "S. Prakash (Assessor)", role: "Assessor", last: "Please re-record the testing step.", time: "Yesterday", unread: 0,
    messages: [
      { from: "them", text: "Your maintenance video is under review.", time: "16:10" },
      { from: "them", text: "Please re-record the testing step.", time: "16:12" },
    ] },
  { id: "c3", with: "UrbanNest Interiors", role: "Employer", last: "Offer sent for the shop job.", time: "Mon", unread: 0,
    messages: [{ from: "them", text: "Offer sent for the shop job.", time: "11:05" }] },
];

export const notifications = [
  { id: "n1", text: "BuildRight Constructions shortlisted you for “Electrician for apartment wiring”.", time: "10 min ago", type: "job", read: false },
  { id: "n2", text: "New job offer from UrbanNest Interiors.", time: "1 hr ago", type: "offer", read: false },
  { id: "n3", text: "Your Electrical maintenance assessment is under review.", time: "Yesterday", type: "assessment", read: true },
  { id: "n4", text: "Payment of ₹6,300 received.", time: "3 days ago", type: "payment", read: true },
];

export const calendarEvents = [
  { date: "2026-11-25", title: "Emergency fault repair", type: "job" },
  { date: "2026-11-27", title: "Interview: BuildRight", type: "interview" },
  { date: "2026-12-02", title: "Assessment: Electrical Installation L2", type: "assessment" },
  { date: "2026-12-04", title: "Assessment: Plumbing Fundamentals", type: "assessment" },
  { date: "2026-11-28", title: "Switchboard upgrade", type: "job" },
];

export const activity = [
  { text: "Updated availability to Available", time: "Today, 09:12" },
  { text: "Applied to “Electrician for apartment wiring”", time: "21 Nov, 18:40" },
  { text: "Submitted video for Electrical maintenance", time: "20 Nov, 11:02" },
  { text: "Logged in from Chrome on Android", time: "20 Nov, 10:58" },
];

export const plans = [
  { name: "Free", price: "₹0", period: "forever", for: "Workers", features: ["Profile and digital ID", "Apply to jobs", "1 free assessment"], highlight: false },
  { name: "Pro Worker", price: "₹99", period: "per month", for: "Workers", features: ["Priority in search", "Unlimited applications", "3 assessments a year", "Earnings reports"], highlight: false },
  { name: "Business", price: "₹1,999", period: "per month", for: "Employers", features: ["Unlimited job posts", "AI worker recommendations", "Bulk verification", "Workforce dashboard"], highlight: true },
  { name: "Assessor Partner", price: "₹999", period: "per month", for: "Assessors & ITIs", features: ["Create programs", "Issue digital certificates", "Analytics"], highlight: false },
];

export const transactions = [
  { id: "INV-1043", date: "2026-11-20", desc: "Pro Worker – November", amount: "₹99", status: "Paid" },
  { id: "INV-1021", date: "2026-10-20", desc: "Pro Worker – October", amount: "₹99", status: "Paid" },
  { id: "INV-1007", date: "2026-10-02", desc: "Assessment fee – Plumbing Fundamentals", amount: "₹199", status: "Refunded" },
];

export const testimonials = [
  { name: "Ramesh Kumar", role: "Electrician, Bengaluru", text: "I had 6 years of experience and no certificate. Two verified skills later, I get calls from contractors every week." },
  { name: "Priya Nair", role: "HR, BuildRight Constructions", text: "We check a worker's credential by QR on site. Hiring time dropped from days to hours." },
  { name: "S. Prakash", role: "Assessor, Govt ITI", text: "Video evidence with a checklist lets me assess workers who can't travel to a centre." },
];

export const stories = [
  { title: "From daily wages to site supervisor", who: "Suresh Gowda, Mason", text: "Verified brickwork and plastering skills helped Suresh land a 2-month villa contract and lead a team of six." },
  { title: "A carpenter's portfolio goes digital", who: "Joseph D'Souza, Carpenter", text: "Joseph's portfolio and certificate brought him modular-kitchen clients across Mangaluru." },
  { title: "First certificate at 42", who: "Farida Begum, Plumber", text: "Farida passed her first assessment from her phone and now charges a verified-skill rate." },
];

export const blogPosts = [
  { id: "b1", title: "5 safety checks every electrician should film", date: "2026-11-15", tag: "Guides", read: "4 min" },
  { id: "b2", title: "How QR credentials are changing site hiring", date: "2026-11-08", tag: "Industry", read: "6 min" },
  { id: "b3", title: "Preparing for your first skill assessment", date: "2026-10-30", tag: "Workers", read: "5 min" },
];

export const faqs = [
  { q: "Is KaushalProof free for workers?", a: "Yes. Creating a profile, applying to jobs and your first assessment are free." },
  { q: "How does skill verification work?", a: "You submit a short video of a real task. An AI pre-check highlights checklist items, and a qualified assessor makes the final decision." },
  { q: "How can an employer check a certificate?", a: "Scan the QR code on the worker's digital ID or certificate. It opens a live verification page." },
  { q: "Which languages are supported?", a: "English, Hindi and Kannada, with more coming soon." },
  { q: "Can I get a refund for an assessment?", a: "Yes, if you cancel at least 24 hours before your scheduled slot." },
];

export const tickets = [
  { id: "T-2201", subject: "Video upload stuck at 90%", status: "Open", updated: "Today" },
  { id: "T-2187", subject: "Change registered phone number", status: "Resolved", updated: "18 Nov" },
];

export const careers = [
  { role: "Field Partnerships Lead", place: "Bengaluru", type: "Full-time" },
  { role: "Frontend Engineer (React)", place: "Remote, India", type: "Full-time" },
  { role: "Kannada Content Associate", place: "Bengaluru", type: "Internship" },
];

export const rankings = workers
  .map((w) => ({ ...w, score: Math.round(w.rating * 18 + w.verified.length * 4 + Math.min(w.years, 10)) }))
  .sort((a, b) => b.score - a.score);

export function workerById(id) {
  return workers.find((w) => w.id === id);
}
export function employerById(id) {
  return employers.find((e) => e.id === id);
}
export function jobById(id) {
  return jobs.find((j) => j.id === id);
}
