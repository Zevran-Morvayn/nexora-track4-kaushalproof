import { useState } from "react";
import { Phone, Video, Send, Users, Megaphone, Bell, Briefcase, Award, Wallet, ChevronLeft, ChevronRight, Shield, Smartphone, Download, Trash2 } from "lucide-react";
import { Card, CardHeader, PageHeader, Button, Badge, statusColor, Table, Input, Select, Textarea, Tabs, Avatar, Empty } from "../../components/ui";
import { FaqList } from "../public/Info";
import { WorkerDashboard } from "../worker/Worker";
import { EmployerDashboard } from "../employer/Employer";
import { AssessorDashboard } from "../assessor/Assessor";
import { useApp } from "../../context/AppContext";
import { conversations, notifications as allNotifications, calendarEvents, activity, plans, transactions, tickets } from "../../data/mock";

export function Dashboard() {
  const { user } = useApp();
  if (user.role === "employer") return <EmployerDashboard />;
  if (user.role === "assessor") return <AssessorDashboard />;
  return <WorkerDashboard />;
}

export function Messages() {
  const { notify } = useApp();
  const [convos, setConvos] = useState(conversations);
  const [active, setActive] = useState(convos[0].id);
  const [text, setText] = useState("");
  const c = convos.find((x) => x.id === active);
  function send(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setConvos(convos.map((x) => (x.id === active ? { ...x, messages: [...x.messages, { from: "me", text, time: "now" }], last: text } : x)));
    setText("");
  }
  return (
    <div>
      <PageHeader title="Messages" action={<div className="flex gap-2"><Button variant="outline"><Users size={16} /> Group rooms</Button><Button variant="outline"><Megaphone size={16} /> Announcements</Button></div>} />
      <Card className="grid md:grid-cols-3 h-[70vh] overflow-hidden">
        <div className="border-r border-slate-200 dark:border-slate-800 overflow-y-auto">
          {convos.map((x) => (
            <button key={x.id} onClick={() => setActive(x.id)} className={`w-full text-left p-4 flex gap-3 border-b border-slate-100 dark:border-slate-800 ${active === x.id ? "bg-brand-50 dark:bg-brand-700/20" : ""}`}>
              <Avatar initials={x.with.split(" ").map((p) => p[0]).slice(0, 2).join("")} size="sm" />
              <div className="flex-1 min-w-0">
                <div className="flex justify-between"><p className="font-semibold text-sm truncate">{x.with}</p><span className="text-xs text-slate-400">{x.time}</span></div>
                <p className="text-sm text-slate-500 truncate">{x.last}</p>
              </div>
              {x.unread > 0 && <span className="bg-brand-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{x.unread}</span>}
            </button>
          ))}
        </div>
        <div className="md:col-span-2 flex flex-col">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div><p className="font-semibold">{c.with}</p><p className="text-xs text-emerald-600">Online</p></div>
            <div className="flex gap-1">
              <Button variant="ghost" onClick={() => notify("Voice call (demo)")} aria-label="Voice call"><Phone size={18} /></Button>
              <Button variant="ghost" onClick={() => notify("Video call (demo)")} aria-label="Video call"><Video size={18} /></Button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 dark:bg-slate-950">
            {c.messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "me" ? "justify-end" : ""}`}>
                <div className={`max-w-xs rounded-2xl px-4 py-2 text-sm ${m.from === "me" ? "bg-brand-600 text-white rounded-br-sm" : "bg-white dark:bg-slate-800 rounded-bl-sm"}`}>
                  {m.text}<p className={`text-[10px] mt-1 ${m.from === "me" ? "text-brand-100" : "text-slate-400"}`}>{m.time}</p>
                </div>
              </div>
            ))}
          </div>
          <form onSubmit={send} className="p-3 border-t border-slate-200 dark:border-slate-800 flex gap-2">
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 outline-none" />
            <Button aria-label="Send"><Send size={16} /></Button>
          </form>
        </div>
      </Card>
    </div>
  );
}

const nIcon = { job: Briefcase, offer: Briefcase, assessment: Award, payment: Wallet };

export function Notifications() {
  const [list, setList] = useState(allNotifications);
  return (
    <div className="max-w-3xl">
      <PageHeader title="Notifications" action={<Button variant="outline" onClick={() => setList(list.map((n) => ({ ...n, read: true })))}>Mark all as read</Button>} />
      <Card className="divide-y divide-slate-100 dark:divide-slate-800">
        {list.map((n) => {
          const Icon = nIcon[n.type] || Bell;
          return (
            <div key={n.id} className={`p-4 flex gap-3 ${n.read ? "" : "bg-brand-50/60 dark:bg-brand-700/10"}`}>
              <span className="w-9 h-9 rounded-xl bg-brand-100 dark:bg-brand-700/30 text-brand-700 dark:text-brand-100 flex items-center justify-center shrink-0"><Icon size={18} /></span>
              <div className="flex-1"><p className="text-sm">{n.text}</p><p className="text-xs text-slate-400 mt-1">{n.time}</p></div>
              {!n.read && <span className="w-2 h-2 rounded-full bg-brand-600 mt-2" />}
            </div>
          );
        })}
      </Card>
      <p className="text-xs text-slate-500 mt-3">Email, SMS and push notification preferences are in Settings.</p>
    </div>
  );
}

export function CalendarPage() {
  const [month, setMonth] = useState(10); // 0-based: November
  const year = 2026;
  const first = new Date(year, month, 1).getDay();
  const daysIn = new Date(year, month + 1, 0).getDate();
  const label = new Date(year, month, 1).toLocaleString("en-IN", { month: "long", year: "numeric" });
  const cells = [...Array(first).fill(null), ...Array.from({ length: daysIn }, (_, i) => i + 1)];
  const color = { job: "bg-brand-600", interview: "bg-violet-600", assessment: "bg-amber-500" };
  return (
    <div>
      <PageHeader title="Calendar" subtitle="Jobs, interviews and assessments in one place." />
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" onClick={() => setMonth((m) => Math.max(0, m - 1))} aria-label="Previous month"><ChevronLeft /></Button>
          <p className="font-semibold">{label}</p>
          <Button variant="ghost" onClick={() => setMonth((m) => Math.min(11, m + 1))} aria-label="Next month"><ChevronRight /></Button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-500 mb-1">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => <div key={d}>{d}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((d, i) => {
            const date = d && `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
            const evs = d ? calendarEvents.filter((e) => e.date === date) : [];
            return (
              <div key={i} className={`min-h-20 rounded-lg p-1.5 text-xs ${d ? "bg-slate-50 dark:bg-slate-800/50" : ""}`}>
                {d && <p className="font-semibold">{d}</p>}
                {evs.map((e) => <p key={e.title} className={`${color[e.type]} text-white rounded px-1 py-0.5 mt-1 truncate`}>{e.title}</p>)}
              </div>
            );
          })}
        </div>
        <div className="flex gap-4 mt-4 text-xs">
          {Object.entries(color).map(([k, c]) => <span key={k} className="flex items-center gap-1 capitalize"><span className={`w-3 h-3 rounded ${c}`} />{k}</span>)}
        </div>
      </Card>
    </div>
  );
}

export function ActivityLog() {
  return (
    <div className="max-w-3xl">
      <PageHeader title="Activity log" />
      <Card className="p-6">
        <ol className="relative border-l border-slate-200 dark:border-slate-800 ml-2 space-y-6">
          {activity.map((a) => (
            <li key={a.text} className="ml-4">
              <span className="absolute -left-1.5 w-3 h-3 rounded-full bg-brand-600 mt-1.5" />
              <p className="text-sm">{a.text}</p>
              <p className="text-xs text-slate-400">{a.time}</p>
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}

export function Billing() {
  const { notify } = useApp();
  return (
    <div>
      <PageHeader title="Plans & billing" />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {plans.map((p) => (
          <Card key={p.name} className={`p-5 flex flex-col ${p.highlight ? "ring-2 ring-brand-500" : ""}`}>
            <p className="font-semibold">{p.name}</p>
            <p className="text-xs text-slate-500">{p.for}</p>
            <p className="text-2xl font-bold mt-2">{p.price}<span className="text-sm font-normal text-slate-500"> {p.period}</span></p>
            <ul className="mt-3 space-y-1 text-sm flex-1">{p.features.map((f) => <li key={f}>✓ {f}</li>)}</ul>
            <Button variant={p.highlight ? "primary" : "outline"} className="mt-4" onClick={() => notify("Redirecting to payment gateway (demo)")}>Choose plan</Button>
          </Card>
        ))}
      </div>
      <Card className="mt-6">
        <CardHeader title="Transaction history" subtitle="Download invoices or request a refund" />
        <Table
          columns={["Invoice", "Date", "Description", "Amount", "Status", ""]}
          rows={transactions.map((t) => [
            <span className="font-mono">{t.id}</span>, t.date, t.desc, t.amount, <Badge color={statusColor(t.status)}>{t.status}</Badge>,
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" className="!py-1"><Download size={14} /> Invoice</Button>
              {t.status === "Paid" && <Button variant="ghost" className="!py-1" onClick={() => notify("Refund request submitted")}>Refund</Button>}
            </div>,
          ])}
        />
      </Card>
    </div>
  );
}

export function Support() {
  const { notify } = useApp();
  return (
    <div>
      <PageHeader title="Support" subtitle="Raise a ticket or browse common questions." />
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">New support ticket</h3>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); notify("Ticket created: T-2210"); e.target.reset(); }}>
            <Input label="Subject" required />
            <Select label="Category" options={["Account", "Skill verification", "Jobs", "Payments", "Other"]} />
            <Textarea label="Describe the issue" required />
            <Button>Submit ticket</Button>
          </form>
        </Card>
        <Card>
          <CardHeader title="My tickets" />
          <Table columns={["Ticket", "Subject", "Status", "Updated"]} rows={tickets.map((t) => [t.id, t.subject, <Badge color={statusColor(t.status)}>{t.status}</Badge>, t.updated])} />
        </Card>
      </div>
      <h2 className="text-lg font-bold mt-8 mb-3">FAQs</h2>
      <FaqList />
    </div>
  );
}

export function Settings() {
  const { user, theme, toggleTheme, lang, setLang, notify } = useApp();
  const [tab, setTab] = useState("Account");
  return (
    <div className="max-w-3xl">
      <PageHeader title="Settings" />
      <Tabs tabs={["Account", "Security", "Notifications", "Preferences"]} active={tab} onChange={setTab} />
      <Card className="p-6">
        {tab === "Account" && (
          <div className="grid sm:grid-cols-2 gap-4">
            <Input label="Name" defaultValue={user.name} />
            <Input label="Email" defaultValue={user.email} />
            <Input label="Phone" defaultValue="98XXXXXX10" />
            <Select label="Role" options={[user.role]} disabled />
            <div className="sm:col-span-2 flex justify-between pt-2">
              <Button variant="ghost" className="text-red-600"><Trash2 size={16} /> Delete account</Button>
              <Button onClick={() => notify("Account updated")}>Save</Button>
            </div>
          </div>
        )}
        {tab === "Security" && (
          <div className="space-y-4">
            <Input label="Current password" type="password" />
            <Input label="New password" type="password" />
            <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800 p-4">
              <span className="flex items-center gap-2 text-sm"><Shield size={16} /> Two-factor authentication (OTP)</span>
              <Badge color="green">On</Badge>
            </div>
            <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-4 text-sm">
              <p className="font-semibold mb-2 flex items-center gap-2"><Smartphone size={16} /> Active sessions</p>
              <p>Chrome on Android · Bengaluru · now</p>
              <p className="text-slate-500">Chrome on Windows · Bengaluru · 2 days ago</p>
            </div>
            <Button onClick={() => notify("Password updated")}>Update password</Button>
          </div>
        )}
        {tab === "Notifications" && (
          <div className="space-y-3">
            {["Email notifications", "SMS notifications", "Push notifications", "Job alerts", "Assessment reminders"].map((n) => (
              <label key={n} className="flex items-center justify-between text-sm py-2 border-b border-slate-100 dark:border-slate-800">
                {n} <input type="checkbox" defaultChecked className="w-4 h-4 accent-brand-600" />
              </label>
            ))}
          </div>
        )}
        {tab === "Preferences" && (
          <div className="space-y-4">
            <label className="block text-sm font-medium">Language
              <select value={lang} onChange={(e) => setLang(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2">
                <option value="en">English</option><option value="hi">हिन्दी</option><option value="kn">ಕನ್ನಡ</option>
              </select>
            </label>
            <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800 p-4">
              <span className="text-sm">Dark mode</span>
              <button onClick={toggleTheme} className={`w-12 h-6 rounded-full relative transition ${theme === "dark" ? "bg-brand-600" : "bg-slate-300"}`} aria-label="Toggle dark mode">
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition ${theme === "dark" ? "left-6" : "left-0.5"}`} />
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

export { Empty, Textarea };
