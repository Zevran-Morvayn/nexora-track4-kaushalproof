import { useState } from "react";
import QRCode from "react-qr-code";
import { ClipboardList, ShieldCheck, Award, Clock, Sparkles, Upload, Trophy, Medal } from "lucide-react";
import { Card, CardHeader, PageHeader, Stat, Button, Badge, statusColor, Table, BarChart, Input, Select, Textarea, Avatar, Rating, Empty } from "../../components/ui";
import { useApp } from "../../context/AppContext";
import { assessmentPrograms, evaluationQueue, certificates, workerById, checklists, categories, rankings } from "../../data/mock";

export function AssessorDashboard() {
  const monthly = [{ m: "Jun", v: 18 }, { m: "Jul", v: 24 }, { m: "Aug", v: 21 }, { m: "Sep", v: 30 }, { m: "Oct", v: 36 }, { m: "Nov", v: 29 }];
  return (
    <div>
      <PageHeader title="Assessor dashboard" subtitle="S. Prakash · Govt ITI, Bengaluru" action={<Button to="/app/assessor/evaluate">Review queue ({evaluationQueue.length})</Button>} />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat icon={ClipboardList} label="Active programs" value={assessmentPrograms.length} tone="brand" />
        <Stat icon={ShieldCheck} label="Pending reviews" value={evaluationQueue.length} tone="accent" />
        <Stat icon={Award} label="Certificates issued" value={158} hint="All time (sample)" tone="green" />
        <Stat icon={Clock} label="Avg. review time" value="6 min" hint="With AI pre-check (sample)" tone="purple" />
      </div>
      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        <Card className="lg:col-span-2">
          <CardHeader title="Assessments completed" subtitle="Sample data" />
          <BarChart data={monthly} valueKey="v" labelKey="m" />
        </Card>
        <Card>
          <CardHeader title="Pass rate by trade" />
          <div className="px-5 pb-5 space-y-3">
            {[["Electrician", 78], ["Plumber", 71], ["Mason", 84], ["Welder", 66]].map(([t, p]) => (
              <div key={t}>
                <div className="flex justify-between text-sm"><span>{t}</span><span className="font-semibold">{p}%</span></div>
                <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full mt-1"><div className="h-2 bg-brand-600 rounded-full" style={{ width: `${p}%` }} /></div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export function Programs() {
  const { notify } = useApp();
  const [list, setList] = useState(assessmentPrograms);
  const [show, setShow] = useState(false);
  function create(e) {
    e.preventDefault();
    const f = new FormData(e.target);
    setList([...list, { id: "p" + Date.now(), title: f.get("title"), trade: f.get("trade"), mode: f.get("mode"), duration: f.get("duration"), fee: f.get("fee"), seats: Number(f.get("seats")), enrolled: 0, next: f.get("date"), assessor: "S. Prakash" }]);
    setShow(false);
    notify("Program created");
  }
  return (
    <div>
      <PageHeader title="Assessment programs" action={<Button onClick={() => setShow(!show)}>{show ? "Cancel" : "Create program"}</Button>} />
      {show && (
        <Card className="p-6 mb-6 fade-up">
          <form onSubmit={create} className="grid sm:grid-cols-3 gap-4">
            <div className="sm:col-span-3"><Input name="title" label="Program title" required placeholder="e.g. Electrical Safety – Level 1" /></div>
            <Select name="trade" label="Trade" options={categories} />
            <Select name="mode" label="Mode" options={["Video evidence", "Video + practical", "On-site practical", "Video + quiz"]} />
            <Input name="duration" label="Duration" defaultValue="30 min" />
            <Input name="fee" label="Fee" defaultValue="Free" />
            <Input name="seats" label="Seats" type="number" defaultValue={20} />
            <Input name="date" label="Next session" type="date" required />
            <div className="sm:col-span-3"><Textarea label="Checklist (one item per line)" placeholder={"Tools shown\nPower isolated first\nCircuit tested"} /></div>
            <div className="sm:col-span-3 flex justify-end"><Button>Save program</Button></div>
          </form>
        </Card>
      )}
      <Card>
        <Table
          columns={["Program", "Trade", "Mode", "Next session", "Enrolled", "Fee"]}
          rows={list.map((p) => [<b>{p.title}</b>, p.trade, p.mode, p.next, `${p.enrolled}/${p.seats}`, p.fee])}
        />
      </Card>
    </div>
  );
}

export function Evaluate() {
  const { notify } = useApp();
  const [queue, setQueue] = useState(evaluationQueue);
  const [openId, setOpenId] = useState(queue[0]?.id);
  const [ai, setAi] = useState(false);
  const [score, setScore] = useState(80);
  const current = queue.find((q) => q.id === openId);
  const w = current && workerById(current.workerId);
  const items = current ? checklists[current.skill] : [];
  const aiStatus = ["Appears demonstrated", "Needs review", "Appears demonstrated", "Not visible"];

  function decide(approved) {
    setQueue(queue.filter((q) => q.id !== openId));
    const next = queue.find((q) => q.id !== openId);
    setOpenId(next?.id);
    setAi(false);
    notify(approved ? `Approved. Certificate issued to ${w.name}.` : "Rejected. Feedback sent to worker.");
  }

  return (
    <div>
      <PageHeader title="Evaluate workers" subtitle="AI suggests; you decide. Only your approval issues a certificate." />
      <div className="grid lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader title={`Queue (${queue.length})`} />
          <div className="px-3 pb-3 space-y-2">
            {queue.map((q) => {
              const qw = workerById(q.workerId);
              return (
                <button key={q.id} onClick={() => { setOpenId(q.id); setAi(false); }} className={`w-full text-left rounded-xl p-3 flex items-center gap-3 border ${openId === q.id ? "border-brand-500 bg-brand-50 dark:bg-brand-700/20" : "border-transparent hover:bg-slate-50 dark:hover:bg-slate-800"}`}>
                  <Avatar initials={qw.photo} size="sm" />
                  <div className="text-sm"><p className="font-semibold">{qw.name}</p><p className="text-slate-500">{q.skill} · {q.submitted}</p></div>
                </button>
              );
            })}
            {queue.length === 0 && <Empty text="All caught up." />}
          </div>
        </Card>
        <div className="lg:col-span-2">
          {current ? (
            <Card className="p-6">
              <div className="flex flex-wrap justify-between gap-3">
                <div><p className="text-xl font-bold">{w.name}</p><p className="text-slate-500">{current.skill} · {w.trade}, {w.years} yrs</p></div>
                <Badge color="amber">Pending</Badge>
              </div>
              <div className="aspect-video bg-slate-900 rounded-xl mt-4 flex items-center justify-center text-slate-400 text-sm">Video player (sample placeholder)</div>
              <div className="flex flex-wrap gap-2 mt-4">
                <Button variant="outline" onClick={() => setAi(true)}><Sparkles size={16} /> Run AI pre-check</Button>
                <Badge color="green">Face matches ID: 97% (sample)</Badge>
              </div>
              <div className="mt-4">
                <p className="font-semibold mb-2">Checklist</p>
                {ai && <p className="text-xs bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-lg p-2 mb-2">Sample AI suggestions. You make the final decision.</p>}
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {items.map((it, i) => (
                    <label key={it} className="flex items-center justify-between py-2 text-sm">
                      <span className="flex items-center gap-2"><input type="checkbox" /> {it}</span>
                      {ai && <Badge color={aiStatus[i] === "Appears demonstrated" ? "green" : aiStatus[i] === "Needs review" ? "amber" : "red"}>{aiStatus[i]}</Badge>}
                    </label>
                  ))}
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4 mt-4">
                <label className="block text-sm font-medium">Score: {score}%
                  <input type="range" min={0} max={100} value={score} onChange={(e) => setScore(e.target.value)} className="w-full mt-2 accent-brand-600" />
                </label>
                <label className="block text-sm font-medium">Upload report
                  <span className="mt-1 flex items-center gap-2 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-500"><Upload size={16} /> Attach PDF (optional)</span>
                </label>
              </div>
              <div className="mt-4"><Textarea label="Remarks for the worker" placeholder="e.g. Good isolation; please show the final test clearly." /></div>
              <div className="flex gap-3 mt-4">
                <Button variant="success" className="flex-1" onClick={() => decide(true)}>Approve & issue certificate</Button>
                <Button variant="danger" className="flex-1" onClick={() => decide(false)}>Reject</Button>
              </div>
            </Card>
          ) : (
            <Card className="p-6"><Empty text="Select a submission to review." /></Card>
          )}
        </div>
      </div>
    </div>
  );
}

export function Certificates() {
  return (
    <div>
      <PageHeader title="Certificates issued" subtitle="Each certificate has a QR code linked to a live verification page." />
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {certificates.map((c) => {
          const w = workerById(c.workerId);
          return (
            <Card key={c.id} className="p-5 flex gap-4 items-center">
              <div className="bg-white p-1.5 rounded-lg"><QRCode value={`${window.location.origin}/verify/${c.id}`} size={72} /></div>
              <div className="text-sm">
                <p className="font-semibold">{w.name}</p>
                <p>{c.skill}</p>
                <p className="text-slate-500">{c.issued} · {c.score}%</p>
                <p className="font-mono text-brand-600">{c.id}</p>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export function Rankings() {
  return (
    <div>
      <PageHeader title="Worker rankings" subtitle="Score combines rating, verified skills and experience (sample formula)." />
      <Card>
        <Table
          columns={["Rank", "Worker", "Trade", "Verified skills", "Rating", "Score"]}
          rows={rankings.map((w, i) => [
            i < 3 ? <Medal className={["text-amber-500", "text-slate-400", "text-orange-700"][i]} size={20} /> : `#${i + 1}`,
            <div className="flex items-center gap-2"><Avatar initials={w.photo} size="sm" />{w.name}</div>,
            w.trade,
            w.verified.length,
            <Rating value={w.rating} />,
            <b>{w.score}</b>,
          ])}
        />
      </Card>
    </div>
  );
}

export function AssessmentHistory() {
  const rows = [
    ...certificates.map((c) => [c.issued, workerById(c.workerId).name, c.skill, `${c.score}%`, <Badge color="green">Approved</Badge>]),
    ["2026-10-12", "Imran Pasha", "Gas welding", "48%", <Badge color="red">Rejected</Badge>],
  ];
  return (
    <div>
      <PageHeader title="Assessment history" action={<Button variant="outline">Export CSV</Button>} />
      <Card><Table columns={["Date", "Worker", "Skill", "Score", "Result"]} rows={rows} /></Card>
    </div>
  );
}
