import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { HardHat, Building2, ClipboardCheck, Apple } from "lucide-react";
import { Card, Button, Input } from "../../components/ui";
import { Logo, ThemeToggle } from "../../components/PublicLayout";
import { useApp } from "../../context/AppContext";

// Mock authentication. HACK DAY: connect to the real auth API.

function Shell({ title, subtitle, children }) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between bg-gradient-to-br from-brand-700 to-brand-500 text-white p-12">
        <div className="[&_a]:!text-white"><Logo /></div>
        <div>
          <p className="text-3xl font-bold leading-snug">Verified skills.<br />Trusted hiring.</p>
          <p className="text-brand-100 mt-3">Join workers, employers and assessors building India’s skilled workforce.</p>
        </div>
        <p className="text-sm text-brand-100">Sample prototype</p>
      </div>
      <div className="flex flex-col p-6">
        <div className="flex justify-between lg:justify-end"><span className="lg:hidden"><Logo /></span><ThemeToggle /></div>
        <div className="flex-1 flex items-center justify-center">
          <div className="w-full max-w-md fade-up">
            <h1 className="text-2xl font-bold">{title}</h1>
            {subtitle && <p className="text-slate-500 mt-1">{subtitle}</p>}
            <div className="mt-6">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SocialButtons({ onClick }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <Button variant="outline" type="button" onClick={onClick}>
        <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C41 35.5 44 30.2 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
        Google
      </Button>
      <Button variant="outline" type="button" onClick={onClick}><Apple size={16} /> Apple</Button>
    </div>
  );
}

function Divider() {
  return <div className="flex items-center gap-3 my-5 text-xs text-slate-400"><span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />or<span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" /></div>;
}

export function Login() {
  const { login } = useApp();
  const navigate = useNavigate();
  const [role, setRole] = useState("worker");
  const go = () => { login(role); navigate("/app"); };
  return (
    <Shell title="Welcome back" subtitle="Log in to your account.">
      <SocialButtons onClick={go} />
      <Divider />
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); go(); }}>
        <Input label="Email or phone" defaultValue="ramesh@example.com" />
        <Input label="Password" type="password" defaultValue="demo1234" />
        <div className="flex justify-end"><Link to="/forgot-password" className="text-sm text-brand-600">Forgot password?</Link></div>
        <Button className="w-full !py-3">Log in</Button>
      </form>
      <Card className="p-4 mt-6">
        <p className="text-xs font-semibold text-slate-500 mb-2">DEMO: log in as</p>
        <div className="grid grid-cols-3 gap-2">
          {["worker", "employer", "assessor"].map((r) => (
            <button key={r} onClick={() => setRole(r)} className={`rounded-lg py-2 text-sm capitalize border ${role === r ? "border-brand-500 bg-brand-50 dark:bg-brand-700/30 font-semibold" : "border-slate-200 dark:border-slate-700"}`}>{r}</button>
          ))}
        </div>
      </Card>
      <p className="text-sm text-center mt-6">New here? <Link to="/register" className="text-brand-600 font-semibold">Create an account</Link></p>
    </Shell>
  );
}

const roles = [
  ["worker", HardHat, "Worker", "Find jobs and get skills verified"],
  ["employer", Building2, "Employer", "Hire verified workers"],
  ["assessor", ClipboardCheck, "Assessor", "Assess skills and issue certificates"],
];

export function Register() {
  const [role, setRole] = useState("worker");
  const navigate = useNavigate();
  return (
    <Shell title="Create your account" subtitle="Choose how you’ll use the platform.">
      <div className="grid grid-cols-3 gap-2 mb-6">
        {roles.map(([key, Icon, label, desc]) => (
          <button key={key} onClick={() => setRole(key)} className={`rounded-xl p-3 text-left border transition ${role === key ? "border-brand-500 bg-brand-50 dark:bg-brand-700/30" : "border-slate-200 dark:border-slate-700"}`}>
            <Icon size={20} className="text-brand-600" />
            <p className="font-semibold text-sm mt-2">{label}</p>
            <p className="text-xs text-slate-500 hidden sm:block">{desc}</p>
          </button>
        ))}
      </div>
      <SocialButtons onClick={() => navigate("/verify-otp", { state: { role } })} />
      <Divider />
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); navigate("/verify-otp", { state: { role } }); }}>
        <Input label={role === "employer" ? "Company name" : "Full name"} required />
        <Input label="Email" type="email" required />
        <Input label="Mobile number" type="tel" required />
        <Input label="Password" type="password" required minLength={8} />
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" required className="mt-1" /> I agree to the <Link to="/legal/terms" className="text-brand-600">Terms</Link> and <Link to="/legal/privacy" className="text-brand-600">Privacy policy</Link></label>
        <Button className="w-full !py-3">Continue</Button>
      </form>
      <p className="text-sm text-center mt-6">Already have an account? <Link to="/login" className="text-brand-600 font-semibold">Log in</Link></p>
    </Shell>
  );
}

export function VerifyOtp() {
  const { login } = useApp();
  const navigate = useNavigate();
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const location = useLocation();
  const role = location.state?.role || "worker";
  function setDigit(i, v) {
    if (!/^\d?$/.test(v)) return;
    const next = [...code];
    next[i] = v;
    setCode(next);
    if (v && i < 5) document.getElementById(`otp-${i + 1}`)?.focus();
  }
  return (
    <Shell title="Verify your number" subtitle="Enter the 6-digit code we sent you. (Demo: any digits work.)">
      <form onSubmit={(e) => { e.preventDefault(); login(role); navigate("/app"); }}>
        <div className="flex gap-2 justify-between">
          {code.map((d, i) => (
            <input key={i} id={`otp-${i}`} value={d} onChange={(e) => setDigit(i, e.target.value)} inputMode="numeric" maxLength={1} aria-label={`Digit ${i + 1}`}
              className="w-12 h-14 text-center text-xl font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 outline-none" />
          ))}
        </div>
        <Button className="w-full !py-3 mt-6" disabled={code.some((d) => !d)}>Verify and continue</Button>
        <p className="text-sm text-center mt-4 text-slate-500">Didn’t get it? <button type="button" className="text-brand-600 font-semibold">Resend code</button></p>
      </form>
    </Shell>
  );
}

export function ForgotPassword() {
  const [sent, setSent] = useState(false);
  return (
    <Shell title="Forgot password?" subtitle="We’ll send you a reset link.">
      {sent ? (
        <div className="space-y-4">
          <p className="text-emerald-600">Reset link sent. Check your email.</p>
          <Button to="/reset-password" variant="outline" className="w-full">Open reset page (demo)</Button>
        </div>
      ) : (
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
          <Input label="Email" type="email" required />
          <Button className="w-full !py-3">Send reset link</Button>
        </form>
      )}
      <p className="text-sm text-center mt-6"><Link to="/login" className="text-brand-600">Back to log in</Link></p>
    </Shell>
  );
}

export function ResetPassword() {
  const navigate = useNavigate();
  const { notify } = useApp();
  return (
    <Shell title="Set a new password">
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); notify("Password updated. Please log in."); navigate("/login"); }}>
        <Input label="New password" type="password" required minLength={8} />
        <Input label="Confirm password" type="password" required minLength={8} />
        <Button className="w-full !py-3">Update password</Button>
      </form>
    </Shell>
  );
}
