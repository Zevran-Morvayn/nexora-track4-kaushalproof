import { useState } from "react";
import { Briefcase, Users, UserCheck, Clock, Sparkles, CalendarPlus, Check, Building2, Upload, Star } from "lucide-react";
import { Card, CardHeader, PageHeader, Stat, Button, Badge, statusColor, Table, BarChart, Input, Select, Textarea, Tabs, Avatar, Rating, VerifiedBadge, Empty } from "../../components/ui";
import { WorkerCard } from "../../components/cards";
import { BrowseWorkers } from "../public/Browse";
import { useApp } from "../../context/AppContext";
import { jobs, workers, employerById, categories, attendance } from "../../data/mock";

const company = () => employerById("e1");
const myJobs = () => jobs.filter((j) => j.employerId === "e1");

export function EmployerDashboard() {
  const hiresByMonth = [{ m: "Jun", v: 6 }, { m: "Jul", v: 9 }, { m: "Aug", v: 7 }, { m: "Sep", v: 12 }, { m: "Oct", v: 15 }, { m: "Nov", v: 11 }];
  const recs = workers.filter((w) => w.verified.length && w.available).slice(0, 3);
  return (
    <div>
      <PageHeader title={company().name} subtitle="Hiring overview" action={<Button to="/app/employer/post-job">Post a job</Button>} />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat icon={Briefcase} label="Open jobs" value={myJobs().filter((j) => j.status === "Open").length} tone="brand" />
        <Stat icon={Users} label="New applicants" value={43} hint="This week (sample)" tone="purple" />
        <Stat icon={UserCheck} label="Active workers" value={28} tone="green" />
        <Stat icon={Clock} label="Avg. time to hire" value="1.8 days" hint="Down from 6 days (sample)" tone="accent" />
      </div>
      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        <Card className="lg:col-span-2">
          <CardHeader title="Hires per month" subtitle="Sample data" />
          <BarChart data={hiresByMonth} valueKey="v" labelKey="m" />
        </Card>
        <Card>
          <CardHeader title="Job status" />
          <div className="px-5 pb-5 space-y-3">
            {myJobs().map((j) => (
              <div key={j.id} className="flex items-center justify-between text-sm">
                <span className="truncate pr-2">{j.title}</span>
                <Badge color={statusColor(j.status)}>{j.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <h2 className="text-lg font-bold mt-8 mb-3 flex items-center gap-2"><Sparkles size={18} className="text-brand-600" /> AI-recommended workers for your open jobs</h2>
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">{recs.map((w) => <WorkerCard key={w.id} w={w} />)}</div>
    </div>
  );
}

export function CompanyProfile() {
  const c = company();
  const { notify } = useApp();
  return (
    <div>
      <PageHeader title="Company profile" action={<Button onClick={() => notify("Company profile saved")}>Save</Button>} />
      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="p-6 text-center h-fit">
          <div className="w-20 h-20 mx-auto rounded-2xl bg-brand-600 text-white flex items-center justify-center"><Building2 size={36} /></div>
          <p className="font-semibold mt-3">{c.name}</p>
          <p className="text-sm text-slate-500">{c.industry}</p>
          <div className="mt-2"><Rating value={c.rating} /></div>
          <Badge color="green">Verified employer</Badge>
          <Button variant="outline" className="w-full mt-4"><Upload size={16} /> Change logo</Button>
        </Card>
        <Card className="p-6 lg:col-span-2 grid sm:grid-cols-2 gap-4">
          <Input label="Company name" defaultValue={c.name} />
          <Input label="Industry" defaultValue={c.industry} />
          <Input label="City" defaultValue={c.city} />
          <Input label="Company size" defaultValue={c.size} />
          <Input label="GSTIN" defaultValue="29ABCDE1234F1Z5 (sample)" />
          <Input label="Website" defaultValue="buildright.example" />
          <div className="sm:col-span-2"><Textarea label="About" defaultValue="Residential construction across Bengaluru since 2011." /></div>
        </Card>
      </div>
    </div>
  );
}

export function EmployerJobs() {
  const [list, setList] = useState(myJobs());
  const { notify } = useApp();
  function close(id) {
    setList(list.map((j) => (j.id === id ? { ...j, status: "Closed" } : j)));
    notify("Job closed");
  }
  return (
    <div>
      <PageHeader title="Job listings" action={<Button to="/app/employer/post-job">Post a job</Button>} />
      <Card>
        <Table
          columns={["Job", "Location", "Pay", "Applicants", "Status", ""]}
          rows={list.map((j) => [
            <div><p className="font-medium">{j.title}</p><p className="text-xs text-slate-500">{j.type} · {j.posted}</p></div>,
            `${j.area}, ${j.city}`,
            j.pay,
            j.applicants,
            <Badge color={statusColor(j.status)}>{j.status}</Badge>,
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" className="!py-1" to="/app/employer/post-job">Edit</Button>
              {j.status !== "Closed" && <Button variant="ghost" className="!py-1 text-red-600" onClick={() => close(j.id)}>Close</Button>}
            </div>,
          ])}
        />
      </Card>
    </div>
  );
}

export function PostJob() {
  const { notify } = useApp();
  return (
    <div className="max-w-3xl">
      <PageHeader title="Post a job" subtitle="Verified workers matching your skills are notified instantly." />
      <Card className="p-6">
        <form className="grid sm:grid-cols-2 gap-4" onSubmit={(e) => { e.preventDefault(); notify("Job posted. Matching workers notified."); e.target.reset(); }}>
          <div className="sm:col-span-2"><Input label="Job title" placeholder="e.g. Electrician for apartment wiring" required /></div>
          <Select label="Trade" options={categories} />
          <Select label="Job type" options={["Daily wage", "Contract", "Full-time", "Part-time"]} />
          <Input label="Area" placeholder="e.g. HSR Layout" required />
          <Input label="City" defaultValue="Bengaluru" required />
          <Input label="Pay" placeholder="e.g. ₹900/day" required />
          <Input label="Workers needed" type="number" defaultValue={1} min={1} />
          <Input label="Start date" type="date" />
          <Select label="Required verification" options={["Any", "Verified skill preferred", "Verified skill required"]} />
          <div className="sm:col-span-2"><Textarea label="Description" placeholder="Describe the work, hours and any tools provided." /></div>
          <div className="sm:col-span-2 flex gap-3 justify-end">
            <Button variant="outline" type="button">Save draft</Button>
            <Button>Publish job</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

export function FindWorkers() {
  return (
    <div>
      <PageHeader title="Find workers" subtitle="Filter by skill, location and verification. Sort by distance to find nearby workers." />
      <BrowseWorkers embedded />
    </div>
  );
}

export function Candidates() {
  const { notify } = useApp();
  const initial = [
    { w: workers[0], job: "Electrician for apartment wiring", stage: "Shortlisted" },
    { w: workers[1], job: "Electrician for apartment wiring", stage: "Applied" },
    { w: workers[3], job: "Mason for villa project", stage: "Interviewing" },
    { w: workers[5], job: "Welder for gate fabrication", stage: "Hired" },
  ];
  const [list, setList] = useState(initial);
  const [tab, setTab] = useState("All");
  const set = (i, stage, msg) => { setList(list.map((c, k) => (k === i ? { ...c, stage } : c))); notify(msg); };
  const shown = list.map((c, i) => ({ ...c, i })).filter((c) => tab === "All" || c.stage === tab);
  return (
    <div>
      <PageHeader title="Candidates" subtitle="Shortlist, interview and hire." />
      <Tabs tabs={["All", "Applied", "Shortlisted", "Interviewing", "Hired"]} active={tab} onChange={setTab} />
      <div className="space-y-3">
        {shown.map(({ w, job, stage, i }) => (
          <Card key={i} className="p-4 flex flex-wrap items-center gap-4">
            <Avatar initials={w.photo} />
            <div className="flex-1 min-w-48">
              <p className="font-semibold">{w.name}</p>
              <p className="text-sm text-slate-500">{job}</p>
              <div className="flex gap-1 mt-1">{w.verified.map((s) => <VerifiedBadge key={s}>{s}</VerifiedBadge>)}</div>
            </div>
            <Badge color={statusColor(stage)}>{stage}</Badge>
            <div className="flex flex-wrap gap-2">
              {stage === "Applied" && <Button variant="outline" className="!py-1.5" onClick={() => set(i, "Shortlisted", "Shortlisted")}><Star size={14} /> Shortlist</Button>}
              {stage === "Shortlisted" && <Button variant="outline" className="!py-1.5" onClick={() => set(i, "Interviewing", "Interview scheduled for 27 Nov, 11:00")}><CalendarPlus size={14} /> Schedule interview</Button>}
              {stage === "Interviewing" && <Button variant="success" className="!py-1.5" onClick={() => set(i, "Hired", "Worker hired")}><Check size={14} /> Hire</Button>}
              <Button variant="ghost" className="!py-1.5" to="/app/messages">Message</Button>
            </div>
          </Card>
        ))}
        {shown.length === 0 && <Empty text="No candidates in this stage." />}
      </div>
    </div>
  );
}

export function Workforce() {
  const team = workers.slice(0, 5);
  return (
    <div>
      <PageHeader title="Workforce" subtitle="Your hired workers and today’s attendance." />
      <Card>
        <Table
          columns={["Worker", "Trade", "Site", "Today", "Attendance (Nov)", "Rating"]}
          rows={team.map((w, i) => [
            <div className="flex items-center gap-2"><Avatar initials={w.photo} size="sm" />{w.name}</div>,
            w.trade,
            ["HSR Layout", "Sarjapur", "HSR Layout", "Sarjapur", "Peenya"][i],
            <Badge color={i === 2 ? "red" : "green"}>{i === 2 ? "Absent" : "Present"}</Badge>,
            `${attendance.filter((d) => d === "P").length - i}/${attendance.length}`,
            <Rating value={w.rating} />,
          ])}
        />
      </Card>
    </div>
  );
}

export function SavedWorkers() {
  const { saved } = useApp();
  const list = workers.filter((w) => saved.includes(w.id));
  return (
    <div>
      <PageHeader title="Saved workers" subtitle="Bookmark workers from search to find them here." />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">{list.map((w) => <WorkerCard key={w.id} w={w} />)}</div>
      {list.length === 0 && <Empty text="No saved workers yet. Tap the bookmark on any worker card." />}
    </div>
  );
}
