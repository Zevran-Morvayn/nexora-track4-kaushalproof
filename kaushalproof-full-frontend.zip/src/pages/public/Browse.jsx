import { useMemo, useState } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import QRCode from "react-qr-code";
import { MapPin, Calendar, Clock, IndianRupee, Users, Briefcase, ArrowLeft, Navigation } from "lucide-react";
import { Card, CardHeader, PageHeader, Button, Badge, Avatar, Rating, VerifiedBadge, Empty, Input, Select } from "../../components/ui";
import { WorkerCard, JobCard } from "../../components/cards";
import { workers, jobs, assessmentPrograms, categories, workerById, certificates, workHistory } from "../../data/mock";
import { useApp } from "../../context/AppContext";

export function BrowseWorkers({ embedded = false }) {
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");
  const [trade, setTrade] = useState(params.get("trade") || "All trades");
  const [city, setCity] = useState(params.get("city") || "");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [availableOnly, setAvailableOnly] = useState(false);
  const [sort, setSort] = useState("Best match");

  const list = useMemo(() => {
    let r = workers.filter(
      (w) =>
        (trade === "All trades" || w.trade === trade) &&
        (!city || w.city.toLowerCase().includes(city.toLowerCase())) &&
        (!q || (w.name + w.trade + w.verified.join(" ")).toLowerCase().includes(q.toLowerCase())) &&
        (!verifiedOnly || w.verified.length) &&
        (!availableOnly || w.available)
    );
    if (sort === "Nearest") r = [...r].sort((a, b) => a.distanceKm - b.distanceKm);
    if (sort === "Top rated") r = [...r].sort((a, b) => b.rating - a.rating);
    if (sort === "Most experienced") r = [...r].sort((a, b) => b.years - a.years);
    return r;
  }, [q, trade, city, verifiedOnly, availableOnly, sort]);

  return (
    <div className={embedded ? "" : "max-w-7xl mx-auto px-4 py-10"}>
      {!embedded && <PageHeader title="Browse workers" subtitle="Search skill-verified workers by trade, location and availability." />}
      <Card className="p-4 mb-6 grid sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
        <Input label="Search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name or skill" className="lg:col-span-2" />
        <Select label="Trade" value={trade} onChange={(e) => setTrade(e.target.value)} options={["All trades", ...categories]} />
        <Input label="City" value={city} onChange={(e) => setCity(e.target.value)} placeholder="Any" />
        <Select label="Sort" value={sort} onChange={(e) => setSort(e.target.value)} options={["Best match", "Nearest", "Top rated", "Most experienced"]} />
        <div className="flex flex-col gap-1 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" checked={verifiedOnly} onChange={(e) => setVerifiedOnly(e.target.checked)} /> Verified only</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={availableOnly} onChange={(e) => setAvailableOnly(e.target.checked)} /> Available now</label>
        </div>
      </Card>
      {sort === "Nearest" && (
        <p className="text-sm text-slate-500 mb-4 flex items-center gap-1"><Navigation size={14} /> Sorted by distance from you (sample location: Jayanagar, Bengaluru)</p>
      )}
      <p className="text-sm text-slate-500 mb-3">{list.length} workers found</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {list.map((w) => <WorkerCard key={w.id} w={w} />)}
      </div>
      {list.length === 0 && <Empty text="No workers match these filters." />}
    </div>
  );
}

export function WorkerPublicProfile() {
  const { id } = useParams();
  const w = workerById(id);
  const { user, notify } = useApp();
  if (!w) return <div className="max-w-3xl mx-auto px-4 py-10"><Empty text="Worker not found." /></div>;
  const certs = certificates.filter((c) => c.workerId === w.id);
  const profileUrl = `${window.location.origin}/workers/${w.id}`;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <Link to="/workers" className="text-sm text-slate-500 flex items-center gap-1 mb-4"><ArrowLeft size={14} /> Back to workers</Link>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6 flex flex-col sm:flex-row gap-5">
            <Avatar initials={w.photo} size="lg" />
            <div className="flex-1">
              <h1 className="text-2xl font-bold">{w.name}</h1>
              <p className="text-slate-500">{w.trade} · {w.years} years’ experience</p>
              <p className="text-sm text-slate-500 flex items-center gap-1 mt-1"><MapPin size={14} />{w.area}, {w.city}</p>
              <div className="flex flex-wrap items-center gap-3 mt-3">
                <Rating value={w.rating} count={w.reviews} />
                <Badge color={w.available ? "green" : "gray"}>{w.available ? "Available" : "Busy"}</Badge>
                <span className="font-semibold">₹{w.rate}/day</span>
              </div>
              <p className="mt-3 text-slate-600 dark:text-slate-300">{w.bio}</p>
              <div className="flex gap-2 mt-4">
                <Button onClick={() => notify(user ? "Invite sent" : "Log in as an employer to invite")}>Invite to job</Button>
                <Button variant="outline" to={user ? "/app/messages" : "/login"}>Message</Button>
              </div>
            </div>
          </Card>
          <Card>
            <CardHeader title="Verified skills" subtitle="Issued after an assessor reviewed real work" />
            <div className="px-5 pb-5 space-y-3">
              {certs.map((c) => (
                <div key={c.id} className="flex items-center justify-between border border-slate-200 dark:border-slate-800 rounded-xl p-3">
                  <div>
                    <VerifiedBadge>{c.skill}</VerifiedBadge>
                    <p className="text-xs text-slate-500 mt-1">by {c.assessor} · {c.issued} · score {c.score}%</p>
                  </div>
                  <Link to={`/verify/${c.id}`} className="text-sm font-mono text-brand-600">{c.id}</Link>
                </div>
              ))}
              {w.pending.map((p) => <div key={p} className="text-sm text-slate-500">⏳ {p} (assessment pending)</div>)}
              {certs.length === 0 && w.pending.length === 0 && <p className="text-sm text-slate-500">No verified skills yet.</p>}
            </div>
          </Card>
          <Card>
            <CardHeader title="Reviews" />
            <div className="px-5 pb-5 space-y-4">
              {workHistory.slice(0, 2).map((h) => (
                <div key={h.id} className="border-b border-slate-100 dark:border-slate-800 pb-3 last:border-0">
                  <div className="flex justify-between"><p className="font-medium">{h.employer}</p><Rating value={h.rating} /></div>
                  <p className="text-sm text-slate-500">{h.job}</p>
                  <p className="text-sm mt-1">Punctual, neat work and explained everything clearly.</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
        <Card className="p-6 h-fit text-center">
          <p className="font-semibold">QR profile</p>
          <p className="text-sm text-slate-500 mb-4">Scan to view this verified profile</p>
          <div className="bg-white p-3 rounded-xl inline-block"><QRCode value={profileUrl} size={160} /></div>
          <p className="text-xs text-slate-500 mt-3 break-all">{profileUrl}</p>
        </Card>
      </div>
    </div>
  );
}

export function BrowseJobs() {
  const [trade, setTrade] = useState("All trades");
  const [q, setQ] = useState("");
  const list = jobs.filter((j) => j.status !== "Closed" && (trade === "All trades" || j.trade === trade) && (!q || j.title.toLowerCase().includes(q.toLowerCase())));
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <PageHeader title="Browse jobs" subtitle="Open jobs from verified employers." />
      <Card className="p-4 mb-6 grid sm:grid-cols-3 gap-3">
        <Input label="Search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Job title" />
        <Select label="Trade" value={trade} onChange={(e) => setTrade(e.target.value)} options={["All trades", ...categories]} />
      </Card>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((j) => <JobCard key={j.id} j={j} action={<Button to="/login" className="!py-1.5">Apply</Button>} />)}
      </div>
      {list.length === 0 && <Empty text="No open jobs for this trade yet." />}
    </div>
  );
}

export function BrowseAssessments() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <PageHeader title="Skill assessments" subtitle="Get a skill verified by a qualified assessor and earn a QR certificate." />
      <div className="grid md:grid-cols-2 gap-4">
        {assessmentPrograms.map((p) => (
          <Card key={p.id} className="p-6 fade-up">
            <div className="flex justify-between">
              <Badge color="blue">{p.trade}</Badge>
              <Badge color={p.enrolled >= p.seats ? "red" : "green"}>{p.enrolled >= p.seats ? "Full" : `${p.seats - p.enrolled} seats left`}</Badge>
            </div>
            <h3 className="font-semibold text-lg mt-3">{p.title}</h3>
            <div className="grid grid-cols-2 gap-2 text-sm text-slate-600 dark:text-slate-400 mt-3">
              <span className="flex items-center gap-1"><Briefcase size={14} /> {p.mode}</span>
              <span className="flex items-center gap-1"><Clock size={14} /> {p.duration}</span>
              <span className="flex items-center gap-1"><IndianRupee size={14} /> {p.fee}</span>
              <span className="flex items-center gap-1"><Calendar size={14} /> Next: {p.next}</span>
              <span className="flex items-center gap-1"><Users size={14} /> Assessor: {p.assessor}</span>
            </div>
            <Button to="/login" className="mt-4" disabled={p.enrolled >= p.seats}>Book a slot</Button>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function VerifyCertificate() {
  const { id } = useParams();
  const c = certificates.find((x) => x.id === id);
  const w = c && workerById(c.workerId);
  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <Card className={`p-8 border-2 ${c ? "border-emerald-400" : "border-red-300"}`}>
        {c ? (
          <>
            <p className="text-2xl font-bold text-center text-emerald-600">✓ Valid certificate</p>
            <dl className="mt-6 space-y-2 text-sm">
              {[["Worker", w.name], ["Trade", w.trade], ["Verified skill", c.skill], ["Assessed by", c.assessor], ["Score", `${c.score}%`], ["Issued", c.issued], ["Certificate ID", c.id]].map(([k, v]) => (
                <div key={k} className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-1"><dt className="text-slate-500">{k}</dt><dd className="font-medium">{v}</dd></div>
              ))}
            </dl>
          </>
        ) : (
          <p className="text-2xl font-bold text-center text-red-600">Certificate not found</p>
        )}
      </Card>
    </div>
  );
}
