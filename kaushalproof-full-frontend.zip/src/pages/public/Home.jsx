import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, ShieldCheck, QrCode, Sparkles, MapPin, Zap, Plug, Hammer, Paintbrush, Wrench, Flame, BrickWall, Smartphone, Apple, Play } from "lucide-react";
import { Button, Card, Rating } from "../../components/ui";
import { WorkerCard, JobCard } from "../../components/cards";
import { workers, jobs, testimonials, categories } from "../../data/mock";
import { APP_NAME } from "../../context/AppContext";

const catIcons = { Electrician: Zap, Plumber: Plug, Carpenter: Hammer, Mason: BrickWall, Welder: Flame, Painter: Paintbrush, Mechanic: Wrench };

export default function Home() {
  const [q, setQ] = useState("");
  const [city, setCity] = useState("");
  const navigate = useNavigate();

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-brand-700 via-brand-600 to-brand-500 text-white">
        <div className="max-w-7xl mx-auto px-4 py-16 md:py-24 grid lg:grid-cols-2 gap-10 items-center">
          <div className="fade-up">
            <span className="inline-flex items-center gap-2 bg-white/15 rounded-full px-3 py-1 text-sm"><ShieldCheck size={16} /> Skill-verified workers</span>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight mt-4">Hire skilled workers you can trust.</h1>
            <p className="text-lg text-brand-100 mt-4 max-w-xl">
              {APP_NAME} connects electricians, plumbers, masons and more with employers, backed by skill assessments and QR-verified certificates.
            </p>
            <form
              onSubmit={(e) => { e.preventDefault(); navigate(`/workers?q=${encodeURIComponent(q)}&city=${encodeURIComponent(city)}`); }}
              className="mt-8 bg-white rounded-2xl p-2 flex flex-col sm:flex-row gap-2 text-slate-800 shadow-xl"
            >
              <div className="flex items-center gap-2 px-3 flex-1">
                <Search size={18} className="text-slate-400" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Trade or skill, e.g. Electrician" className="w-full py-2 outline-none" />
              </div>
              <div className="flex items-center gap-2 px-3 sm:border-l border-slate-200">
                <MapPin size={18} className="text-slate-400" />
                <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" className="w-full py-2 outline-none" />
              </div>
              <Button variant="accent" className="!py-3">Search</Button>
            </form>
            <div className="flex gap-6 mt-8 text-sm">
              <div><p className="text-2xl font-bold">12,400+</p><p className="text-brand-100">Workers (sample)</p></div>
              <div><p className="text-2xl font-bold">3,100+</p><p className="text-brand-100">Verified skills</p></div>
              <div><p className="text-2xl font-bold">850+</p><p className="text-brand-100">Employers</p></div>
            </div>
          </div>
          <div className="hidden lg:grid grid-cols-2 gap-4">
            {workers.slice(0, 4).map((w) => (
              <div key={w.id} className="bg-white/10 backdrop-blur rounded-2xl p-4 border border-white/20">
                <p className="font-semibold">{w.name}</p>
                <p className="text-sm text-brand-100">{w.trade} · {w.city}</p>
                <div className="mt-2 text-white"><Rating value={w.rating} count={w.reviews} /></div>
                <p className="mt-2 text-xs bg-emerald-400/20 text-emerald-100 rounded-full px-2 py-0.5 w-fit">✓ {w.verified[0]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-bold">Browse by trade</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mt-6">
          {categories.map((c) => {
            const Icon = catIcons[c];
            return (
              <button key={c} onClick={() => navigate(`/workers?trade=${c}`)} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-brand-500 hover:-translate-y-0.5 transition">
                <span className="w-11 h-11 rounded-xl bg-brand-50 dark:bg-brand-700/30 text-brand-600 dark:text-brand-100 flex items-center justify-center"><Icon size={22} /></span>
                <span className="text-sm font-medium">{c}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-14">
          <h2 className="text-2xl font-bold text-center">How it works</h2>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {[
              [ShieldCheck, "Prove your skill", "Workers submit a short video of a real task. An assessor verifies it, with AI help."],
              [QrCode, "Get a digital certificate", "Approved skills become QR-verified certificates on the worker's digital ID."],
              [Sparkles, "Get matched", "Employers find nearby verified workers, with AI recommendations for each job."],
            ].map(([Icon, title, text], i) => (
              <Card key={title} className="p-6">
                <span className="text-xs font-bold text-brand-600">STEP {i + 1}</span>
                <Icon className="text-brand-600 mt-3" size={28} />
                <h3 className="font-semibold text-lg mt-3">{title}</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">{text}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-bold">Top verified workers</h2>
          <Button variant="ghost" to="/workers">See all</Button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {workers.slice(0, 4).map((w) => <WorkerCard key={w.id} w={w} />)}
        </div>
        <div className="flex items-end justify-between mt-14">
          <h2 className="text-2xl font-bold">Latest jobs</h2>
          <Button variant="ghost" to="/jobs">See all</Button>
        </div>
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          {jobs.slice(0, 3).map((j) => <JobCard key={j.id} j={j} action={<Button variant="outline" to="/login" className="!py-1.5">Apply</Button>} />)}
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-7xl mx-auto px-4 pb-14">
        <h2 className="text-2xl font-bold">What people say</h2>
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          {testimonials.map((t) => (
            <Card key={t.name} className="p-6">
              <p className="text-slate-700 dark:text-slate-300">“{t.text}”</p>
              <p className="font-semibold mt-4">{t.name}</p>
              <p className="text-sm text-slate-500">{t.role}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* App download */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="rounded-3xl bg-slate-900 dark:bg-slate-800 text-white p-8 md:p-12 grid md:grid-cols-2 gap-6 items-center">
          <div>
            <Smartphone size={32} className="text-accent-500" />
            <h2 className="text-2xl md:text-3xl font-bold mt-3">Take {APP_NAME} to the job site</h2>
            <p className="text-slate-300 mt-2">Record skill videos, get job alerts and show your digital ID from your phone.</p>
          </div>
          <div className="flex flex-wrap gap-3 md:justify-end">
            <span className="flex items-center gap-2 bg-white text-slate-900 rounded-xl px-4 py-3 font-semibold"><Play size={18} /> Google Play (coming soon)</span>
            <span className="flex items-center gap-2 bg-white text-slate-900 rounded-xl px-4 py-3 font-semibold"><Apple size={18} /> App Store (coming soon)</span>
          </div>
        </div>
      </section>
    </div>
  );
}
