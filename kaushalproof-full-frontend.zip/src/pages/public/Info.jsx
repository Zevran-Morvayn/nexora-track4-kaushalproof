import { useState } from "react";
import { useParams } from "react-router-dom";
import { ChevronDown, ShieldCheck, Search, QrCode, Sparkles, BarChart3, Languages, Mail, Phone, MapPin, BookOpen, PlayCircle, MessageCircle } from "lucide-react";
import { Card, PageHeader, Button, Input, Textarea, Select, Badge } from "../../components/ui";
import { faqs, stories, testimonials, blogPosts, careers, plans } from "../../data/mock";
import { useApp, APP_NAME } from "../../context/AppContext";

const wrap = "max-w-6xl mx-auto px-4 py-10";

export function About() {
  return (
    <div className={wrap}>
      <PageHeader title={`About ${APP_NAME}`} subtitle="Making skills visible, verifiable and valued." />
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold text-lg">Our mission</h3>
          <p className="text-slate-600 dark:text-slate-400 mt-2">
            Millions of skilled workers learned on the job and have no way to prove it. We help them show real work, get it verified by qualified assessors,
            and connect with employers who value verified skill.
          </p>
        </Card>
        <Card className="p-6">
          <h3 className="font-semibold text-lg">What we believe</h3>
          <ul className="mt-2 space-y-2 text-slate-600 dark:text-slate-400 list-disc pl-5">
            <li>Workers should never pay to be trusted.</li>
            <li>AI assists; qualified people decide.</li>
            <li>Every certificate should be checkable in seconds.</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}

export function Services() {
  const items = [
    [ShieldCheck, "Skill verification", "Video-based assessments reviewed by qualified assessors."],
    [QrCode, "Digital certificates", "QR certificates and digital ID cards employers can verify instantly."],
    [Search, "Worker search", "Find workers by trade, skill, rating and distance."],
    [Sparkles, "AI matching", "Job matching, worker recommendations and skill-gap analysis."],
    [BarChart3, "Workforce analytics", "Track hiring, attendance and performance."],
    [Languages, "Multi-language", "English, Hindi and Kannada interfaces."],
  ];
  return (
    <div className={wrap}>
      <PageHeader title="Services" subtitle="Everything workers, employers and assessors need in one place." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map(([Icon, t, d]) => (
          <Card key={t} className="p-6">
            <Icon className="text-brand-600" />
            <h3 className="font-semibold mt-3">{t}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{d}</p>
          </Card>
        ))}
      </div>
      <h2 className="text-2xl font-bold mt-14 mb-6">Plans</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((p) => (
          <Card key={p.name} className={`p-6 ${p.highlight ? "ring-2 ring-brand-500" : ""}`}>
            {p.highlight && <Badge color="blue">Most popular</Badge>}
            <p className="font-semibold mt-2">{p.name}</p>
            <p className="text-xs text-slate-500">{p.for}</p>
            <p className="text-3xl font-bold mt-3">{p.price}<span className="text-sm font-normal text-slate-500"> {p.period}</span></p>
            <ul className="mt-4 space-y-1 text-sm">{p.features.map((f) => <li key={f}>✓ {f}</li>)}</ul>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function FaqList() {
  const [open, setOpen] = useState(0);
  return (
    <div className="space-y-2">
      {faqs.map((f, i) => (
        <Card key={f.q} className="overflow-hidden">
          <button onClick={() => setOpen(open === i ? -1 : i)} className="w-full flex justify-between items-center p-4 text-left font-medium">
            {f.q} <ChevronDown size={18} className={`transition ${open === i ? "rotate-180" : ""}`} />
          </button>
          {open === i && <p className="px-4 pb-4 text-sm text-slate-600 dark:text-slate-400">{f.a}</p>}
        </Card>
      ))}
    </div>
  );
}

export function Help() {
  return (
    <div className={wrap}>
      <PageHeader title="Help center" subtitle="Guides, answers and support." />
      <Card className="p-4 flex items-center gap-2 mb-8"><Search size={18} className="text-slate-400" /><input placeholder="Search the knowledge base…" className="bg-transparent outline-none w-full" /></Card>
      <div className="grid sm:grid-cols-3 gap-4 mb-10">
        {[[BookOpen, "User guides", "Step-by-step guides for every role"], [PlayCircle, "Video tutorials", "Short videos in English, Hindi and Kannada"], [MessageCircle, "Live chat", "Chat with support, 9 AM–7 PM"]].map(([Icon, t, d]) => (
          <Card key={t} className="p-6"><Icon className="text-brand-600" /><p className="font-semibold mt-3">{t}</p><p className="text-sm text-slate-500">{d}</p></Card>
        ))}
      </div>
      <h2 className="text-xl font-bold mb-4">Frequently asked questions</h2>
      <FaqList />
    </div>
  );
}

export function Contact() {
  const { notify } = useApp();
  return (
    <div className={wrap}>
      <PageHeader title="Contact us" subtitle="We usually reply within one working day." />
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="p-6 md:col-span-2">
          <form className="grid sm:grid-cols-2 gap-4" onSubmit={(e) => { e.preventDefault(); notify("Message sent. We’ll get back to you soon."); e.target.reset(); }}>
            <Input label="Name" required />
            <Input label="Email" type="email" required />
            <Select label="I am a" options={["Worker", "Employer", "Assessor", "Other"]} className="sm:col-span-2" />
            <div className="sm:col-span-2"><Textarea label="Message" required /></div>
            <Button className="sm:col-span-2">Send message</Button>
          </form>
        </Card>
        <Card className="p-6 space-y-4 text-sm">
          <p className="flex gap-2"><Mail size={18} className="text-brand-600" /> support@kaushalproof.example</p>
          <p className="flex gap-2"><Phone size={18} className="text-brand-600" /> 1800-000-0000 (sample)</p>
          <p className="flex gap-2"><MapPin size={18} className="text-brand-600" /> Bengaluru, Karnataka</p>
        </Card>
      </div>
    </div>
  );
}

export function Stories() {
  return (
    <div className={wrap}>
      <PageHeader title="Success stories" subtitle="Real outcomes from verified skills (sample stories)." />
      <div className="grid md:grid-cols-3 gap-4">
        {stories.map((s) => (
          <Card key={s.title} className="p-6"><p className="font-semibold">{s.title}</p><p className="text-sm text-brand-600 mt-1">{s.who}</p><p className="text-sm text-slate-600 dark:text-slate-400 mt-3">{s.text}</p></Card>
        ))}
      </div>
      <h2 className="text-xl font-bold mt-12 mb-4">Reviews & testimonials</h2>
      <div className="grid md:grid-cols-3 gap-4">
        {testimonials.map((t) => (
          <Card key={t.name} className="p-6"><p>“{t.text}”</p><p className="font-semibold mt-3">{t.name}</p><p className="text-sm text-slate-500">{t.role}</p></Card>
        ))}
      </div>
    </div>
  );
}

export function Blog() {
  return (
    <div className={wrap}>
      <PageHeader title="Blog & news" />
      <div className="grid md:grid-cols-3 gap-4">
        {blogPosts.map((b) => (
          <Card key={b.id} className="overflow-hidden">
            <div className="h-36 bg-gradient-to-br from-brand-500 to-brand-700" />
            <div className="p-5"><Badge color="blue">{b.tag}</Badge><p className="font-semibold mt-2">{b.title}</p><p className="text-xs text-slate-500 mt-1">{b.date} · {b.read} read</p></div>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function Careers() {
  return (
    <div className={wrap}>
      <PageHeader title="Careers" subtitle={`Help us build ${APP_NAME}.`} />
      <Card className="divide-y divide-slate-100 dark:divide-slate-800">
        {careers.map((c) => (
          <div key={c.role} className="flex items-center justify-between p-5">
            <div><p className="font-semibold">{c.role}</p><p className="text-sm text-slate-500">{c.place} · {c.type}</p></div>
            <Button variant="outline">Apply</Button>
          </div>
        ))}
      </Card>
    </div>
  );
}

export function Legal() {
  const { page } = useParams();
  const privacy = page === "privacy";
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <PageHeader title={privacy ? "Privacy policy" : "Terms & conditions"} subtitle="Sample text for the prototype. Replace with reviewed legal copy." />
      <Card className="p-6 space-y-4 text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
        {privacy ? (
          <>
            <p><b>What we collect.</b> Profile details, skill videos you upload, and how you use the platform.</p>
            <p><b>How we use it.</b> To verify skills, match jobs and keep accounts secure. Skill videos are private by default.</p>
            <p><b>Your choices.</b> You can download or delete your data at any time from Settings.</p>
          </>
        ) : (
          <>
            <p><b>Accounts.</b> You must give accurate information and keep your login secure.</p>
            <p><b>Assessments.</b> Submitting someone else’s work leads to account removal.</p>
            <p><b>Payments.</b> Fees and refunds follow the plan you choose.</p>
          </>
        )}
      </Card>
    </div>
  );
}

export function NotFound() {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <p className="text-6xl font-extrabold text-brand-600">404</p>
      <p className="mt-2 text-slate-500">This page doesn’t exist.</p>
      <Button to="/" className="mt-6">Go home</Button>
    </div>
  );
}
