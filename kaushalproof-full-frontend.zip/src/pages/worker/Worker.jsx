import { useState } from "react";
import QRCode from "react-qr-code";
import { Briefcase, Star, Wallet, ShieldCheck, Upload, Camera, FileText, Sparkles, Phone, Check, X, Download } from "lucide-react";
import { Card, CardHeader, PageHeader, Stat, Button, Badge, statusColor, Table, BarChart, Input, Select, Textarea, Tabs, VerifiedBadge, Avatar, Empty } from "../../components/ui";
import { JobCard } from "../../components/cards";
import { useApp } from "../../context/AppContext";
import { workerById, jobs, applications, offers, earnings, workHistory, attendance, certificates, employerById, jobById, assessmentPrograms, checklists, categories } from "../../data/mock";

const me = () => workerById("w1");

export function WorkerDashboard() {
  const w = me();
  const { notify } = useApp();
  const [offerState, setOfferState] = useState(Object.fromEntries(offers.map((o) => [o.id, o.status])));
  const matches = jobs.filter((j) => j.trade === w.trade && j.status === "Open");
  return (
    <div>
      <PageHeader title={`Welcome back, ${w.name.split(" ")[0]}`} subtitle="Here’s what’s happening with your work." />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat icon={ShieldCheck} label="Verified skills" value={w.verified.length} hint={`${w.pending.length} pending review`} tone="green" />
        <Stat icon={Briefcase} label="Active applications" value={applications.filter((a) => a.status !== "Rejected").length} tone="brand" />
        <Stat icon={Wallet} label="Earned this month" value="₹23,900" hint="+8% vs last month (sample)" tone="accent" />
        <Stat icon={Star} label="Rating" value={w.rating} hint={`${w.reviews} reviews`} tone="purple" />
      </div>
      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        <Card className="lg:col-span-2">
          <CardHeader title="Job requests & offers" subtitle="Employers who invited you directly" />
          <div className="px-5 pb-5 space-y-3">
            {offers.map((o) => (
              <div key={o.id} className="flex flex-wrap items-center gap-3 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
                <div className="flex-1 min-w-48">
                  <p className="font-semibold">{o.title}</p>
                  <p className="text-sm text-slate-500">{employerById(o.employerId).name} · {o.date} · {o.pay}</p>
                </div>
                {offerState[o.id] === "Pending" ? (
                  <div className="flex gap-2">
                    <Button variant="success" className="!py-1.5" onClick={() => { setOfferState({ ...offerState, [o.id]: "Accepted" }); notify("Offer accepted"); }}><Check size={16} /> Accept</Button>
                    <Button variant="outline" className="!py-1.5" onClick={() => { setOfferState({ ...offerState, [o.id]: "Declined" }); notify("Offer declined"); }}><X size={16} /> Decline</Button>
                  </div>
                ) : (
                  <Badge color={statusColor(offerState[o.id])}>{offerState[o.id]}</Badge>
                )}
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="AI skill-gap analysis" subtitle="Based on jobs near you" />
          <div className="px-5 pb-5 space-y-3 text-sm">
            <p className="flex gap-2"><Sparkles size={16} className="text-brand-600 shrink-0 mt-0.5" /><span>64% of electrician jobs near you ask for <b>Electrical maintenance</b>. Your assessment is pending.</span></p>
            <p className="flex gap-2"><Sparkles size={16} className="text-brand-600 shrink-0 mt-0.5" /><span>Adding <b>Electrical safety</b> could raise your match rate by about 20% (sample estimate).</span></p>
            <Button variant="outline" to="/app/worker/verification" className="w-full mt-2">Get a skill verified</Button>
          </div>
        </Card>
      </div>
      <h2 className="text-lg font-bold mt-8 mb-3 flex items-center gap-2"><Sparkles size={18} className="text-brand-600" /> AI-matched jobs for you</h2>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {matches.map((j) => <JobCard key={j.id} j={j} action={<Button className="!py-1.5" onClick={() => notify("Application sent")}>Apply</Button>} />)}
      </div>
    </div>
  );
}

export function WorkerProfile() {
  const w = me();
  const { notify } = useApp();
  const [available, setAvailable] = useState(w.available);
  return (
    <div>
      <PageHeader title="My profile" subtitle="A complete profile gets up to 3× more job requests (sample)." action={<Button onClick={() => notify("Profile saved")}>Save changes</Button>} />
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="space-y-6">
          <Card className="p-6 text-center">
            <div className="relative inline-block"><Avatar initials={w.photo} size="lg" /><button className="absolute bottom-0 right-0 bg-brand-600 text-white rounded-full p-1.5" aria-label="Upload photo"><Camera size={14} /></button></div>
            <p className="font-semibold mt-3">{w.name}</p>
            <p className="text-sm text-slate-500">{w.trade}</p>
            <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800 p-3">
              <span className="text-sm font-medium">Availability</span>
              <button onClick={() => setAvailable(!available)} className={`w-12 h-6 rounded-full relative transition ${available ? "bg-emerald-500" : "bg-slate-300"}`} aria-label="Toggle availability">
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition ${available ? "left-6" : "left-0.5"}`} />
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-2">{available ? "Employers can send you job requests" : "Hidden from new job requests"}</p>
          </Card>
          <Card>
            <CardHeader title="Skill verification status" />
            <div className="px-5 pb-5 flex flex-wrap gap-2">
              {w.verified.map((s) => <VerifiedBadge key={s}>{s}</VerifiedBadge>)}
              {w.pending.map((s) => <Badge key={s} color="amber">⏳ {s}</Badge>)}
            </div>
          </Card>
          <Card>
            <CardHeader title="Documents" subtitle="Certificates, ID and resume" />
            <div className="px-5 pb-5 space-y-2 text-sm">
              {["ITI certificate.pdf", "Aadhaar (masked).pdf", "Resume_Ramesh.pdf"].map((d) => (
                <p key={d} className="flex items-center gap-2"><FileText size={16} className="text-slate-400" /> {d}</p>
              ))}
              <Button variant="outline" className="w-full mt-2"><Upload size={16} /> Upload document</Button>
            </div>
          </Card>
        </div>
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Basic details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <Input label="Full name" defaultValue={w.name} />
              <Select label="Trade" defaultValue={w.trade} options={categories} />
              <Input label="Years of experience" type="number" defaultValue={w.years} />
              <Input label="Daily rate (₹)" type="number" defaultValue={w.rate} />
              <Input label="Area" defaultValue={w.area} />
              <Input label="City" defaultValue={w.city} />
              <div className="sm:col-span-2"><Textarea label="About me" defaultValue={w.bio} /></div>
            </div>
          </Card>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Job preferences</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <Select label="Job type" options={["Any", "Daily wage", "Contract", "Full-time"]} />
              <Select label="Travel up to" options={["5 km", "10 km", "25 km", "Anywhere in city"]} defaultValue="10 km" />
              <Select label="Preferred language" options={["English", "Hindi", "Kannada"]} defaultValue="Kannada" />
            </div>
          </Card>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Portfolio gallery</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {["Switchboard", "Panel wiring", "Office lighting", "Villa DB"].map((p, i) => (
                <div key={p} className={`aspect-square rounded-xl flex items-end p-2 text-xs text-white font-medium bg-gradient-to-br ${["from-sky-500 to-blue-700", "from-amber-500 to-orange-700", "from-emerald-500 to-teal-700", "from-violet-500 to-purple-700"][i]}`}>{p}</div>
              ))}
            </div>
            <Button variant="outline" className="mt-4"><Upload size={16} /> Add photos</Button>
          </Card>
          <Card className="p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2"><Phone size={16} /> Emergency contact</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <Input label="Name" defaultValue="Sunita Kumar" />
              <Input label="Relation" defaultValue="Spouse" />
              <Input label="Phone" defaultValue="98XXXXXX21" />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function WorkerJobs() {
  const [tab, setTab] = useState("Browse jobs");
  const { notify } = useApp();
  return (
    <div>
      <PageHeader title="Jobs & applications" />
      <Tabs tabs={["Browse jobs", "My applications", "Work history"]} active={tab} onChange={setTab} />
      {tab === "Browse jobs" && (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {jobs.filter((j) => j.status !== "Closed").map((j) => <JobCard key={j.id} j={j} action={<Button className="!py-1.5" onClick={() => notify("Application sent")}>Apply</Button>} />)}
        </div>
      )}
      {tab === "My applications" && (
        <Card>
          <Table
            columns={["Job", "Employer", "Applied", "Status"]}
            rows={applications.map((a) => {
              const j = jobById(a.jobId);
              return [j.title, employerById(j.employerId).name, a.applied, <Badge color={statusColor(a.status)}>{a.status}</Badge>];
            })}
          />
        </Card>
      )}
      {tab === "Work history" && (
        <Card>
          <Table columns={["Job", "Employer", "Dates", "Paid", "Rating"]} rows={workHistory.map((h) => [h.job, h.employer, `${h.from} → ${h.to}`, h.pay, "★".repeat(h.rating)])} />
        </Card>
      )}
    </div>
  );
}

export function WorkerVerification() {
  const w = me();
  const { notify } = useApp();
  const [program, setProgram] = useState(assessmentPrograms[0].id);
  const [file, setFile] = useState(null);
  const myCerts = certificates.filter((c) => c.workerId === w.id);
  const list = checklists["Electrical maintenance"];
  return (
    <div>
      <PageHeader title="Skill verification" subtitle="Show a real task on video. A qualified assessor decides." />
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Submit a new skill</h3>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); notify("Video submitted for review"); setFile(null); }}>
            <label className="block text-sm font-medium">Assessment program
              <select value={program} onChange={(e) => setProgram(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2">
                {assessmentPrograms.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
              </select>
            </label>
            <div className="rounded-xl bg-brand-50 dark:bg-brand-700/20 p-4 text-sm">
              <p className="font-semibold mb-2">Your video should show:</p>
              <ul className="space-y-1">{list.map((c) => <li key={c}>☐ {c}</li>)}</ul>
              <p className="mt-3 text-xs text-slate-500">Today’s random prompt: say “<b>blue switch 47</b>” at the start, so we know the video is yours.</p>
            </div>
            <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 cursor-pointer hover:border-brand-500">
              <Upload className="text-slate-400" />
              <span className="text-sm">{file ? file.name : "Tap to record or upload a video (max 2 min)"}</span>
              <input type="file" accept="video/*" capture="environment" className="hidden" onChange={(e) => setFile(e.target.files[0])} />
            </label>
            <Button className="w-full" disabled={!file}>Submit for review</Button>
          </form>
        </Card>
        <div className="space-y-6">
          <Card>
            <CardHeader title="In review" />
            <div className="px-5 pb-5 space-y-3">
              {w.pending.map((p) => (
                <div key={p} className="border border-slate-200 dark:border-slate-800 rounded-xl p-4">
                  <div className="flex justify-between"><p className="font-medium">{p}</p><Badge color="amber">Under review</Badge></div>
                  <div className="mt-3 h-2 bg-slate-100 dark:bg-slate-800 rounded-full"><div className="h-2 bg-amber-500 rounded-full w-2/3" /></div>
                  <p className="text-xs text-slate-500 mt-2">Submitted → AI pre-check done → <b>Assessor review</b> → Certificate</p>
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <CardHeader title="My certificates" />
            <div className="px-5 pb-5 space-y-3">
              {myCerts.map((c) => (
                <div key={c.id} className="flex items-center gap-4 border border-slate-200 dark:border-slate-800 rounded-xl p-3">
                  <div className="bg-white p-1.5 rounded-lg"><QRCode value={`${window.location.origin}/verify/${c.id}`} size={64} /></div>
                  <div className="flex-1 text-sm">
                    <p className="font-semibold">{c.skill}</p>
                    <p className="text-slate-500">{c.assessor} · {c.issued} · {c.score}%</p>
                    <p className="font-mono text-brand-600">{c.id}</p>
                  </div>
                  <Button variant="ghost" aria-label="Download"><Download size={16} /></Button>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function WorkerEarnings() {
  const days = attendance;
  const present = days.filter((d) => d === "P").length;
  return (
    <div>
      <PageHeader title="Earnings & attendance" action={<Button variant="outline"><Download size={16} /> Download report</Button>} />
      <div className="grid sm:grid-cols-3 gap-4">
        <Stat icon={Wallet} label="This month" value="₹23,900" tone="accent" />
        <Stat icon={Wallet} label="Last 6 months" value={`₹${earnings.reduce((s, e) => s + e.amount, 0).toLocaleString("en-IN")}`} tone="green" />
        <Stat icon={Briefcase} label="Days worked (Nov)" value={`${present} / ${days.length}`} tone="brand" />
      </div>
      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        <Card className="lg:col-span-2">
          <CardHeader title="Monthly earnings" subtitle="Sample data" />
          <BarChart data={earnings} valueKey="amount" labelKey="month" format={(v) => `₹${(v / 1000).toFixed(1)}k`} />
        </Card>
        <Card>
          <CardHeader title="Attendance – November" subtitle="P present · A absent · H holiday" />
          <div className="px-5 pb-5 grid grid-cols-6 gap-2">
            {days.map((d, i) => (
              <div key={i} className={`aspect-square rounded-lg flex flex-col items-center justify-center text-xs font-semibold ${d === "P" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300" : d === "A" ? "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300" : "bg-slate-100 text-slate-500 dark:bg-slate-800"}`}>
                <span className="text-[10px] font-normal">{i + 1}</span>{d}
              </div>
            ))}
          </div>
        </Card>
      </div>
      <Card className="mt-6">
        <CardHeader title="Recent payments" />
        <Table columns={["Job", "Employer", "Completed", "Amount"]} rows={workHistory.map((h) => [h.job, h.employer, h.to, <b>{h.pay}</b>])} />
      </Card>
    </div>
  );
}

export function WorkerIdCard() {
  const w = me();
  const url = `${window.location.origin}/workers/${w.id}`;
  return (
    <div>
      <PageHeader title="Digital ID card" subtitle="Show this on site. Employers scan the QR to see your verified skills." />
      <div className="max-w-md mx-auto">
        <div className="rounded-3xl overflow-hidden shadow-xl bg-gradient-to-br from-brand-700 to-brand-500 text-white">
          <div className="p-6 flex items-center gap-4">
            <Avatar initials={w.photo} size="lg" />
            <div>
              <p className="text-xl font-bold">{w.name}</p>
              <p className="text-brand-100">{w.trade} · {w.years} yrs</p>
              <p className="text-xs text-brand-100 mt-1">ID: KP-{w.id.toUpperCase()}-2026</p>
            </div>
          </div>
          <div className="bg-white text-slate-800 p-6 flex items-center gap-5">
            <QRCode value={url} size={120} />
            <div className="text-sm space-y-1">
              <p className="font-semibold">Verified skills</p>
              {w.verified.map((s) => <p key={s} className="text-emerald-700">✓ {s}</p>)}
              <p className="text-xs text-slate-500 pt-2">{w.city} · valid while account is active</p>
            </div>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <Button className="flex-1"><Download size={16} /> Download</Button>
          <Button variant="outline" className="flex-1">Share on WhatsApp</Button>
        </div>
      </div>
    </div>
  );
}

export { Empty };
